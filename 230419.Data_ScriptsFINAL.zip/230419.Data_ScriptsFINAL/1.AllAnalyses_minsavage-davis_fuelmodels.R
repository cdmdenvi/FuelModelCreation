#Library for rstudio functions
library (rstudioapi)

#Getting the path of your current open file
current_path <- rstudioapi::getActiveDocumentContext()$path 
setwd(dirname(current_path))
print(getwd())

#Requisite and dependent libraries
library(withr)
library(ggplot2)
library(cluster)
library(factoextra)
library(magrittr)
library(ggpubr)
library(gridGraphics)
library(permute)
library(vegan)
library(cowplot)
library(plot3D)
library(rgl)
library(plot3Drgl)
library(yaml)
library(rmarkdown)
library(backports) 
library(robustbase) 
library(flexmix) 
library(mclust) 
library(prabclus) 
library(diptest) 
library(MVN)
library(Rothermel)
library(mjcgraphics)
library(tidyverse)
library(caret)
library(rpart)
library(rpart.plot)
library(viridis)
library(autoimage)
library(colourvalues)
library(readxl)
library(foreach)
library(iterators)
library(GA)
library(rainbow)
library(pcaPP)
library(fda)
library(zoo)
library(sde)
library(ftsa)
library(forecast)
library(lsmeans)
library(multcomp)
library(multcompView)
library(car)
library(nlme)
library(MASS)
library(rcompanion)
library(VGAM)
library(dplyr)
library(tidyr)
library(forcats)
library(hrbrthemes)
library(RColorBrewer)
library(Rmisc)
library(Hmisc)
library(boot)
library(EnvStats)
library(emmeans)
library(utils)
library(gridExtra)
library(patchwork)

#######################
#Data Cluster Analysis#
#######################

##Read in DATA
f <- read_xlsx("2.AllData_minsavage-davis_fuelmodels.xlsx", sheet = "FinalFuelsnoFormulas")

f.clean <- f[, 3:8]

f.stand <- cbind(f.clean[, 1]/max(f.clean[, 1]), f.clean[, 2]/max(f.clean[, 2]), f.clean[, 3]/max(f.clean[, 3]), f.clean[, 4]/max(f.clean[, 4]), f.clean[, 5]/max(f.clean[, 5]), f.clean[, 6]/max(f.clean[, 6]))

#Cluster for Fine Data
f.dist <- vegdist(f.stand, method = "bray")

f.fit <- hclust(f.dist, method = "ward.D2")

f.height <- cbind(f.fit$merge, f.fit$height)
f.height <- f.height[order(f.height[, 3], decreasing = TRUE),]

f.height <- cbind(f.height, as.matrix(1 - f.height[, 3]/f.height[1, 3]))
colnames(f.height) <- cbind("A", "B", "ht", "info")

plot(f.height[, 4], ylim = c(0, max(f.height[, 4])), xlim = c(0, 24.5), cex = 2, pch = 16, bty = 'n', axes = FALSE, ann = FALSE)
axis(1, at = 6, labels = 6, col.axis = "red", col.tick = "red", las = 1, cex.axis = 1.5, lwd = 1)
axis(1, at = c(0, 5, 10, 15, 20, 25), labels = c(0, 5, 10, 15, 20, 25), col.axis = "black", las = 1, cex.axis = 1.5, lwd = 1)
axis(2, at = c(0, .10, .20, .30, .40, .50, .60, .70, .80, .90, 1), labels = c(0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100), col.axis = "black", las = 1, cex.axis = 1.5, lwd = 1, line = -1)
title(main = "Hierarchical Groupings", cex.main = 2, font.main = 2.5)
mtext("Variation Explained (%)", side = 2, line = 2.5, cex = 2)  
mtext("# of Groups", side = 1, line = 3.4, cex = 2)  
abline(v = 6, col = 'red', lwd = 2)

#Visualize appropriate number of groupings
fscree <- recordPlot()

fscree

rh <- rect.hclust(f.fit, k = 6, border = "red") 

beg_clus <- head(cumsum(c(1, lengths(rh))), -1)

y_clus <- weighted.mean(rev(f.fit$height)[2:3], c(10, 50))

par(mai = c(.2, .8, 0.1, 0.1))

plot(f.fit, ylim = c(0, 1), axes = FALSE, ann = FALSE, labels = FALSE)
axis(2, at = c(0, 2.5), labels = c(0, 2.5), line = -0.75, las = 1, cex.axis = 1.5, lwd = 1.5)
axis(1, at = (1:296), labels = FALSE, col.tick = FALSE, col = "red", las = 1, cex.axis = 1.5, lwd = 1)
rect.hclust(f.fit, k = 6, border = "red") 
mtext("Merger Height", side = 2, line = 2, cex = 2)  
text(x = c(15, 63, 115, 175, 225, 254), y = c(-0.4, -0.4, -0.4, -0.4, -0.4, -0.4), col="red", labels = c("Mature", "L Build", "T Build", "E Build", "Build+", "Pioneer+"), font = 2)

fdend <- recordPlot()

fdend

#Write groupings to disk
fgroups <- cutree(f.fit, k = 6)

f[, 13] <- fgroups
colnames(f)[13] <- "CLUSTER"
write.csv(f, file = "Cluster.csv")

plot.new()

boxplot(f$ML~f$CLUSTER)
boxplot(f$DdWoody~f$CLUSTER)
boxplot(f$Herb~f$CLUSTER)
boxplot(f$LvWoody~f$CLUSTER)
boxplot(f$FBD~f$CLUSTER)

#Determine appropriate moss load for entries
moss.1 <- c()
moss.2 <- c()
moss.3 <- c()
moss.4 <- c()
moss.5 <- c()
moss.6 <- c()

j <- 1
k <- 1
l <- 1
m <- 1
n <- 1
o <- 1

for(i in 1:nrow(f)){
         if(fgroups[i] == 1){
    moss.1[j] = f.clean[i, 1]
    j <- j + 1
  } else if(fgroups[i] == 2){
    moss.2[k] = f.clean[i, 1]
    k <- k + 1
  } else if(fgroups[i] == 3){
    moss.3[l] = f.clean[i, 1]
    l <- l + 1
  } else if(fgroups[i] == 4){
    moss.4[m] = f.clean[i, 1]
    m <- m + 1
  } else if(fgroups[i] == 5){
    moss.5[n] = f.clean[i, 1]
    n <- n + 1
  } else if(fgroups[i] == 6){
    moss.6[o] = f.clean[i, 1]
    o <- o + 1
  }
}

moss.low1 <- quantile(unlist(moss.1), 0.10)
moss.low2 <- quantile(unlist(moss.2), 0.10)
moss.low3 <- quantile(unlist(moss.3), 0.10)
moss.low4 <- quantile(unlist(moss.4), 0.10)
moss.low5 <- quantile(unlist(moss.5), 0.10)
moss.low6 <- quantile(unlist(moss.6), 0.10)

moss.mod1 <- quantile(unlist(moss.1), 0.50)
moss.mod2 <- quantile(unlist(moss.2), 0.50)
moss.mod3 <- quantile(unlist(moss.3), 0.50)
moss.mod4 <- quantile(unlist(moss.4), 0.50)
moss.mod5 <- quantile(unlist(moss.5), 0.50)
moss.mod6 <- quantile(unlist(moss.6), 0.50)

moss.high1 <- quantile(unlist(moss.1), 0.90)
moss.high2 <- quantile(unlist(moss.2), 0.90)
moss.high3 <- quantile(unlist(moss.3), 0.90)
moss.high4 <- quantile(unlist(moss.4), 0.90)
moss.high5 <- quantile(unlist(moss.5), 0.90)
moss.high6 <- quantile(unlist(moss.6), 0.90)

moss.low <- c()
moss.mod <- c()
moss.high <- c()

for(i in 1:nrow(f)){
  if(fgroups[i] == 1){
    if(moss.low1 > f.clean[i, 1]){
    moss.low[i] <- f.clean[i, 1]
    } else {
    moss.low[i] <- moss.low1  
    }
    if(moss.mod1 > f.clean[i, 1]){
      moss.mod[i] <- f.clean[i, 1]
    } else {
      moss.mod[i] <- moss.mod1  
    }
    if(moss.high1 > f.clean[i, 1]){
      moss.high[i] <- f.clean[i, 1]
    } else {
      moss.high[i] <- moss.high1  
    }
  } else if(fgroups[i] == 2){
    if(moss.low2 > f.clean[i, 1]){
      moss.low[i] <- f.clean[i, 1]
    } else {
      moss.low[i] <- moss.low2  
    }
    if(moss.mod2 > f.clean[i, 1]){
      moss.mod[i] <- f.clean[i, 1]
    } else {
      moss.mod[i] <- moss.mod2  
    }
    if(moss.high2 > f.clean[i, 1]){
      moss.high[i] <- f.clean[i, 1]
    } else {
      moss.high[i] <- moss.high2  
    }
  } else if(fgroups[i] == 3){
    if(moss.low3 > f.clean[i, 1]){
      moss.low[i] <- f.clean[i, 1]
    } else {
      moss.low[i] <- moss.low3  
    }
    if(moss.mod3 > f.clean[i, 1]){
      moss.mod[i] <- f.clean[i, 1]
    } else {
      moss.mod[i] <- moss.mod3  
    }
    if(moss.high3 > f.clean[i, 1]){
      moss.high[i] <- f.clean[i, 1]
    } else {
      moss.high[i] <- moss.high3  
    }
  } else if(fgroups[i] == 4){
    if(moss.low4 > f.clean[i, 1]){
      moss.low[i] <- f.clean[i, 1]
    } else {
      moss.low[i] <- moss.low4  
    }
    if(moss.mod4 > f.clean[i, 1]){
      moss.mod[i] <- f.clean[i, 1]
    } else {
      moss.mod[i] <- moss.mod4  
    }
    if(moss.high4 > f.clean[i, 1]){
      moss.high[i] <- f.clean[i, 1]
    } else {
      moss.high[i] <- moss.high4  
    }
  } else if(fgroups[i] == 5){
    if(moss.low5 > f.clean[i, 1]){
      moss.low[i] <- f.clean[i, 1]
    } else {
      moss.low[i] <- moss.low5  
    }
    if(moss.mod5 > f.clean[i, 1]){
      moss.mod[i] <- f.clean[i, 1]
    } else {
      moss.mod[i] <- moss.mod5 
    }
    if(moss.high5 > f.clean[i, 1]){
      moss.high[i] <- f.clean[i, 1]
    } else {
      moss.high[i] <- moss.high5  
    }
  } else if(fgroups[i] == 6){
    if(moss.low6 > f.clean[i, 1]){
      moss.low[i] <- f.clean[i, 1]
    } else {
      moss.low[i] <- moss.low6  
    }
    if(moss.mod6 > f.clean[i, 1]){
      moss.mod[i] <- f.clean[i, 1]
    } else {
      moss.mod[i] <- moss.mod6  
    }
    if(moss.high6 > f.clean[i, 1]){
      moss.high[i] <- f.clean[i, 1]
    } else {
      moss.high[i] <- moss.high6  
    }
  }
}

moss.low
moss.mod
moss.high

mosscomp <- cbind(moss.low, moss.mod, moss.high)
view(mosscomp)

write.csv(mosscomp, "mosscomp.csv")

#Calculate FBD additions from moss
moss.fbd.low <- c()

for(i in 1:length(moss.low)){
  fbd <- (((unlist(moss.low[i])*1000) - 302)/124.5)
  if(fbd <= 0){
  moss.fbd.low[i] <- 0
  } else { 
    moss.fbd.low[i] <- fbd
  }
}

moss.fbd.mod <- c()

for(i in 1:length(moss.mod)){
  fbd <- (((unlist(moss.mod[i])*1000) - 302)/124.5)
  if(fbd <= 0){
  moss.fbd.mod[i] <- 0
  } else { 
    moss.fbd.mod[i] <- fbd
  }
}

moss.fbd.high <- c()

for(i in 1:length(moss.high)){
  fbd <- (((unlist(moss.high[i])*1000) - 302)/124.5)
  if(fbd <= 0){
  moss.fbd.high[i] <- 0
  } else { 
    moss.fbd.high[i] <- fbd
  }
}

fbdcomp <- cbind(moss.fbd.low, moss.fbd.mod, moss.fbd.high)
view(fbdcomp)

write.csv(fbdcomp, "fbdcomp.csv")

#Low Risk NMDS
#column 1 of each scenario is generated with the appropriate ratio of moss/litter + all dead woody + all herbaceous
low.clean <- cbind(unlist(moss.low) + f.clean[, 2], f.clean[, 3], f.clean[, 4], moss.fbd.low + f.clean[, 5], f.clean[, 6])
colnames(low.clean) <- c("DEAD", "HERB", "LW", "FBD", "CBD")
view(low.clean)

low.stand <- cbind(low.clean[, 1]/max(low.clean[, 1]), low.clean[, 2]/max(low.clean[, 2]), low.clean[, 3]/max(low.clean[, 3]), low.clean[, 4]/max(low.clean[, 4]), low.clean[, 5]/max(low.clean[, 5]))
colnames(low.stand) <- c("DEAD", "HERB", "LW", "FBD", "CBD")

low.NMDS1 <- metaMDS(low.stand, k = 1, distance = "bray", try = 20, trymax = 200,  autotransform =FALSE) # k is the number of dim
low.NMDS2 <- metaMDS(low.stand, k = 2, distance = "bray", try = 20, trymax = 200,  autotransform =FALSE) # k is the number of dim
low.NMDS3 <- metaMDS(low.stand, k = 3, distance = "bray", try = 20, trymax = 200,  autotransform =FALSE) # k is the number of dim
low.NMDS4 <- metaMDS(low.stand, k = 4, distance = "bray", try = 20, trymax = 200,  autotransform =FALSE) # k is the number of dim
low.NMDS5 <- metaMDS(low.stand, k = 5, distance = "bray", try = 20, trymax = 200,  autotransform =FALSE) # k is the number of dim
low.NMDS6 <- metaMDS(low.stand, k = 6, distance = "bray", try = 20, trymax = 200,  autotransform =FALSE) # k is the number of dim
low.NMDS7 <- metaMDS(low.stand, k = 7, distance = "bray", try = 20, trymax = 200,  autotransform =FALSE) # k is the number of dim

k <- c(1, 2, 3, 4, 5, 6, 7)
lowstress.fit <- c(low.NMDS1$stress, low.NMDS2$stress, low.NMDS3$stress, low.NMDS4$stress, low.NMDS5$stress, low.NMDS6$stress, low.NMDS7$stress)

plot(k, ylim = c(0, 0.5), lowstress.fit, axes = FALSE, ann = FALSE, pch = 16, cex = 2)
axis(2, at = c(0, .5), labels = c(0, .5), col.axis = "black", las = 1, cex.axis = 1.5, lwd = 1, line = 0)
axis(1, at = c(1, 2, 4, 5, 6, 7), labels = c(1, 2, 4, 5, 6, 7), col.axis = "black", las = 1, cex.axis = 1.5, lwd = 1, line = 0)
axis(1, at = 3, labels = 3, col.axis = "red", col.tick = "red", las = 1, cex.axis = 1.5, lwd = 1)
title(main = "NMDS Dimension Selection - Low Risk", cex.main = 2, font.main = 2.5)
mtext("NMDS Stress", side = 2, line = 2.25, cex = 2)  
mtext("# of Dimensions", side = 1, line = 3.4, cex = 2)  
abline(v = 3, col = 'red', lwd = 2)
lowscree.stress <- recordPlot()

lowscree.stress

#Med Risk NMDS
med.clean <- cbind(unlist(moss.mod) + f.clean[, 2], f.clean[, 3], f.clean[, 4], moss.fbd.mod + f.clean[, 5], f.clean[, 6])
colnames(med.clean) <- c("DEAD", "HERB", "LW", "FBD", "CBD")

med.stand <- cbind(med.clean[, 1]/max(med.clean[, 1]), med.clean[, 2]/max(med.clean[, 2]), med.clean[, 3]/max(med.clean[, 3]), med.clean[, 4]/max(med.clean[, 4]), med.clean[, 5]/max(med.clean[, 5]))
colnames(med.stand) <- c("DEAD", "HERB", "LW", "FBD", "CBD")

med.NMDS1 <- metaMDS(med.stand, k = 1, distance = "bray", try = 20, trymax = 200,  autotransform =FALSE) # k is the number of dim
med.NMDS2 <- metaMDS(med.stand, k = 2, distance = "bray", try = 20, trymax = 200,  autotransform =FALSE) # k is the number of dim
med.NMDS3 <- metaMDS(med.stand, k = 3, distance = "bray", try = 20, trymax = 200,  autotransform =FALSE) # k is the number of dim
med.NMDS4 <- metaMDS(med.stand, k = 4, distance = "bray", try = 20, trymax = 200,  autotransform =FALSE) # k is the number of dim
med.NMDS5 <- metaMDS(med.stand, k = 5, distance = "bray", try = 20, trymax = 200,  autotransform =FALSE) # k is the number of dim
med.NMDS6 <- metaMDS(med.stand, k = 6, distance = "bray", try = 20, trymax = 200,  autotransform =FALSE) # k is the number of dim
med.NMDS7 <- metaMDS(med.stand, k = 7, distance = "bray", try = 20, trymax = 200,  autotransform =FALSE) # k is the number of dim

k <- c(1, 2, 3, 4, 5, 6, 7)
medstress.fit <- c(med.NMDS1$stress, med.NMDS2$stress, med.NMDS3$stress, med.NMDS4$stress, med.NMDS5$stress, med.NMDS6$stress, med.NMDS7$stress)

plot(k, ylim = c(0, .5), medstress.fit, axes = FALSE, ann = FALSE, pch = 16, cex = 2)
axis(2, at = c(0, .5), labels = c(0, .5), col.axis = "black", las = 1, cex.axis = 1.5, lwd = 1, line = 0)
axis(1, at = c(1, 2, 4, 5, 6, 7), labels = c(1, 2, 4, 5, 6, 7), col.axis = "black", las = 1, cex.axis = 1.5, lwd = 1, line = 0)
axis(1, at = 3, labels = 3, col.axis = "red", col.tick = "red", las = 1, cex.axis = 1.5, lwd = 1)
title(main = "NMDS Dimension Selection - Mod Risk", cex.main = 2, font.main = 2.5)
mtext("NMDS Stress", side = 2, line = 2.25, cex = 2)  
mtext("# of Dimensions", side = 1, line = 3.4, cex = 2)  
abline(v = 3, col = 'red', lwd = 2)
medscree.stress <- recordPlot()

medscree.stress

#High Risk NMDS
high.clean <- cbind(unlist(moss.high) + f.clean[, 2], f.clean[, 3], f.clean[, 4], moss.fbd.high + f.clean[, 5], f.clean[, 6])
colnames(high.clean) <- c("DEAD", "HERB", "LW", "FBD", "CBD")

high.stand <- cbind(high.clean[, 1]/max(high.clean[, 1]), high.clean[, 2]/max(high.clean[, 2]), high.clean[, 3]/max(high.clean[, 3]), high.clean[, 4]/max(high.clean[, 4]), high.clean[, 5]/max(high.clean[, 5]))
colnames(high.stand) <- c("DEAD", "HERB", "LW", "FBD", "CBD")

high.NMDS1 <- metaMDS(high.stand, k = 1, distance = "bray", try = 20, trymax = 200,  autotransform =FALSE) # k is the number of dim
high.NMDS2 <- metaMDS(high.stand, k = 2, distance = "bray", try = 20, trymax = 200,  autotransform =FALSE) # k is the number of dim
high.NMDS3 <- metaMDS(high.stand, k = 3, distance = "bray", try = 20, trymax = 200,  autotransform =FALSE) # k is the number of dim
high.NMDS4 <- metaMDS(high.stand, k = 4, distance = "bray", try = 20, trymax = 200,  autotransform =FALSE) # k is the number of dim
high.NMDS5 <- metaMDS(high.stand, k = 5, distance = "bray", try = 20, trymax = 200,  autotransform =FALSE) # k is the number of dim
high.NMDS6 <- metaMDS(high.stand, k = 6, distance = "bray", try = 20, trymax = 200,  autotransform =FALSE) # k is the number of dim
high.NMDS7 <- metaMDS(high.stand, k = 7, distance = "bray", try = 20, trymax = 200,  autotransform =FALSE) # k is the number of dim

k <- c(1, 2, 3, 4, 5, 6, 7)
highstress.fit <- c(high.NMDS1$stress, high.NMDS2$stress, high.NMDS3$stress, high.NMDS4$stress, high.NMDS5$stress, high.NMDS6$stress, high.NMDS7$stress)

plot(k, ylim = c(0, .5), highstress.fit, axes = FALSE, ann = FALSE, pch = 16, cex = 2)
axis(2, at = c(0, .5), labels = c(0, .5), col.axis = "black", las = 1, cex.axis = 1.5, lwd = 1, line = 0)
axis(1, at = c(1, 2, 4, 5, 6, 7), labels = c(1, 2, 4, 5, 6, 7), col.axis = "black", las = 1, cex.axis = 1.5, lwd = 1, line = 0)
axis(1, at = 3, labels = 3, col.axis = "red", col.tick = "red", las = 1, cex.axis = 1.5, lwd = 1)
title(main = "NMDS Dimension Selection - High Risk", cex.main = 2, font.main = 2.5)
mtext("NMDS Stress", side = 2, line = 2.25, cex = 2)  
mtext("# of Dimensions", side = 1, line = 3.4, cex = 2)  
abline(v = 3, col = 'red', lwd = 2)
highscree.stress <- recordPlot()

highscree.stress

##DEFINE ROTH VARS
MODEL <- "S"
SAV <- c(9560,	8810,	8810,	8810,	1000)
MOE <- 30
HEAT <- c(20810,	20810,	20810,	20810,	20810)
MOISTL <- c(15,	15,	15,	60,	60)
MOISTM <- c(20,	20,	20,	75,	75)
MOISTH <- c(25,	25,	25,	90,	90)
WIND <- 0
SLOPE <- 0

#High Rothermel - 11.0231 is the conversion from kg m-2 to t ha-1
HIGHFUEL <- cbind((high.clean[, 1]+high.clean[, 2])*11.0231, 0, 0, 0, high.clean[, 3]*11.0231)
HIGHDEPTH <- high.clean[, 4]

colnames(HIGHFUEL) <- c("1H", "10H", "100H", "LIVEHERB", "LIVEWOOD")

HIGHROTH <- as.data.frame(matrix(ncol = 25, nrow = 296))
HIGHROTH[, 1] <- MODEL 
HIGHROTH[, 2:6] <- HIGHFUEL[1:296, 1:5]
HIGHROTH[, 7] <- SAV[1]
HIGHROTH[, 8] <- SAV[2]
HIGHROTH[, 9] <- SAV[3]
HIGHROTH[, 10] <- SAV[4]
HIGHROTH[, 11] <- SAV[5]
HIGHROTH[, 12] <- HIGHDEPTH[1:296]
HIGHROTH[, 13] <- MOE
HIGHROTH[, 14] <- HEAT[1]
HIGHROTH[, 15] <- HEAT[2]
HIGHROTH[, 16] <- HEAT[3]
HIGHROTH[, 17] <- HEAT[4]
HIGHROTH[, 18] <- HEAT[5]
HIGHROTH[, 19] <- MOISTL[1]
HIGHROTH[, 20] <- MOISTL[2]
HIGHROTH[, 21] <- MOISTL[3]
HIGHROTH[, 22] <- MOISTL[4]
HIGHROTH[, 23] <- MOISTL[5]
HIGHROTH[, 24] <- WIND
HIGHROTH[, 25] <- SLOPE

highR <- ros(HIGHROTH[1:296, 1], HIGHROTH[1:296, 2:6], HIGHROTH[1:296, 7:11], HIGHROTH[1:296, 12], HIGHROTH[1:296, 13], HIGHROTH[1:296, 14:18], HIGHROTH[1:296, 19:23], 5, HIGHROTH[1:296, 25])
highros <- highR[15]
highrosUL <- unlist(highros)

write.csv(highrosUL, "highros.csv")

mean(highrosUL)
min.highros<-min(highrosUL)
max.highros<-max(highrosUL)

#Med Rothermel
MEDFUEL <- cbind((med.clean[, 1]+med.clean[, 2])*11.0231, 0, 0, 0, med.clean[, 3]*11.0231)
MEDDEPTH <- med.clean[, 4]

colnames(MEDFUEL) <- c("1H", "10H", "100H", "LIVEHERB", "LIVEWOOD")

MEDROTH <- as.data.frame(matrix(ncol = 25, nrow = 296))
MEDROTH[, 1] <- MODEL 
MEDROTH[, 2:6] <- MEDFUEL[1:296, 1:5]
MEDROTH[, 7] <- SAV[1]
MEDROTH[, 8] <- SAV[2]
MEDROTH[, 9] <- SAV[3]
MEDROTH[, 10] <- SAV[4]
MEDROTH[, 11] <- SAV[5]
MEDROTH[, 12] <- MEDDEPTH[1:296]
MEDROTH[, 13] <- MOE
MEDROTH[, 14] <- HEAT[1]
MEDROTH[, 15] <- HEAT[2]
MEDROTH[, 16] <- HEAT[3]
MEDROTH[, 17] <- HEAT[4]
MEDROTH[, 18] <- HEAT[5]
MEDROTH[, 19] <- MOISTM[1]
MEDROTH[, 20] <- MOISTM[2]
MEDROTH[, 21] <- MOISTM[3]
MEDROTH[, 22] <- MOISTM[4]
MEDROTH[, 23] <- MOISTM[5]
MEDROTH[, 24] <- WIND
MEDROTH[, 25] <- SLOPE

medR <- ros(MEDROTH[1:296, 1], MEDROTH[1:296, 2:6], MEDROTH[1:296, 7:11], MEDROTH[1:296, 12], MEDROTH[1:296, 13], MEDROTH[1:296, 14:18], MEDROTH[1:296, 19:23], 5, MEDROTH[1:296, 25])
medros <- medR[15]
medrosUL <- unlist(medros)

write.csv(medrosUL, "medros.csv")

mean(medrosUL)
min.medros<-min(medrosUL)
max.medros<-max(medrosUL)

#Low Rothermel
LOWFUEL <- cbind((low.clean[, 1]+low.clean[, 2])*11.0231, 0, 0, 0, low.clean[, 3]*11.0231)
LOWDEPTH <- low.clean[, 4]

colnames(LOWFUEL) <- c("1H", "10H", "100H", "LIVEHERB", "LIVEWOOD")

LOWROTH <- as.data.frame(matrix(ncol = 25, nrow = 296))
LOWROTH[, 1] <- MODEL 
LOWROTH[, 2:6] <- LOWFUEL[1:296, 1:5]
LOWROTH[, 7] <- SAV[1]
LOWROTH[, 8] <- SAV[2]
LOWROTH[, 9] <- SAV[3]
LOWROTH[, 10] <- SAV[4]
LOWROTH[, 11] <- SAV[5]
LOWROTH[, 12] <- LOWDEPTH[1:296]
LOWROTH[, 13] <- MOE
LOWROTH[, 14] <- HEAT[1]
LOWROTH[, 15] <- HEAT[2]
LOWROTH[, 16] <- HEAT[3]
LOWROTH[, 17] <- HEAT[4]
LOWROTH[, 18] <- HEAT[5]
LOWROTH[, 19] <- MOISTH[1]
LOWROTH[, 20] <- MOISTH[2]
LOWROTH[, 21] <- MOISTH[3]
LOWROTH[, 22] <- MOISTH[4]
LOWROTH[, 23] <- MOISTH[5]
LOWROTH[, 24] <- WIND
LOWROTH[, 25] <- SLOPE

lowR <- ros(LOWROTH[1:296, 1], LOWROTH[1:296, 2:6], LOWROTH[1:296, 7:11], LOWROTH[1:296, 12], LOWROTH[1:296, 13], LOWROTH[1:296, 14:18], LOWROTH[1:296, 19:23], 5, LOWROTH[1:296, 25])
lowros <- lowR[15]
lowrosUL <- unlist(lowros)

write.csv(lowrosUL, "lowros.csv")

mean(lowrosUL)
min.lowros<-min(lowrosUL)
max.lowros<-max(lowrosUL)

#COMBINE
all <- matrix(nrow = 296*3, ncol = 3)
colnames(all) <- c("no.","ROS", "set")

all <- data.frame(all)

all[, 1] <- 1:888
all[c(1:296), 2] <- highrosUL
all[c(297:592), 2] <- medrosUL
all[c(593:888), 2] <- lowrosUL

all[c(1:296), 3] <- "highros"
all[c(297:592), 3] <- "medros"
all[c(593:888), 3] <- "lowros"

#High Plots
#Region and Cluster
high.ord <- ordiplot(high.NMDS3, type = "text")

highx <- high.NMDS3$points[, 1]
highy <- high.NMDS3$points[, 2]

#plot(highx, highy, xlim = c(-1, 1), ylim = c(-1.25, 1), cex = 2, pch = c(22, 23)[high[, 1]], col = "white", bg = c("palevioletred2", "springgreen4", "steelblue4", "goldenrod", "magenta3", "skyblue2")[f[, 13]], bty = 'n', ann = FALSE, axes = FALSE)
plot(highx, highy, xlim = c(-1, 1), ylim = c(-1.25, 1), cex = 2, pch = c(22, 23)[unlist(f[, 1])], col = "white", bg = "white", bty = 'n', ann = FALSE, axes = FALSE)
axis(1, at = c(-1, 0.0, 1), labels = c(-1, 0.0, 1), col.axis = "black", las = 1, cex.axis = 1.5, lwd = 1)
axis(2, at = c(-1, 0.0, 1), labels = c(-1, 0.0, 1), col.axis = "black", las = 1, cex.axis = 1.5, lwd = 1, line = 0)
#title(main = "Cluster NMDS - High Risk", cex.main = 2.5, font.main = 2.5, line = 0.25, adj = 0.25)
#mtext("Component 2", side = 2, line = 2, cex = 2)  
#mtext("Component 1", side = 1, line = 3.5, cex = 2, adj = 0.375) 
#legend(.9, 0.75, cex = 1.5, border = 0, bty = "n", y.intersp = 1, x.intersp = 1, legend = c("Scotland", "Norway"), pch = c(15, 18), col = c("black"))
#legend(.9, 0.25, cex = 1.5, border = 0, bty = "n", y.intersp = 1, x.intersp = 1, legend = c("Group 1", "Group 2", "Group 3", "Group 4", "Group 5", "Group 6"), pch = 15, col = c("palevioletred2", "springgreen4", "steelblue4", "goldenrod", "magenta3", "skyblue2"))
ordiellipse(high.NMDS3, fgroups, kind = "sd", show.groups = "1", label = F, col = "palevioletred2", lwd = 2, cex = 2)
ordiellipse(high.NMDS3, fgroups, kind = "sd", show.groups = "2", label = F, col = "springgreen4",  lwd = 2, cex = 2)
ordiellipse(high.NMDS3, fgroups, kind = "sd", show.groups = "3", label = F, col = "steelblue4", lwd = 2, cex = 2)
ordiellipse(high.NMDS3, fgroups, kind = "sd", show.groups = "4", label = F, col = "goldenrod", lwd = 2, cex = 2)
ordiellipse(high.NMDS3, fgroups, kind = "sd", show.groups = "5", label = F, col = "magenta3", lwd = 2, cex = 2)
ordiellipse(high.NMDS3, fgroups, kind = "sd", show.groups = "6", label = F, col = "skyblue2", lwd = 2, cex = 2)
text(high.ord, "species", col = "black", labels = c("DEAD", "HERB", "LW", "FBD", "CBD"), font = 2, cex = 1.5)
#text(0, 0, cex = 1.5, labels = "(0, 0)")

high1.nmds <- recordPlot()

region <- f[, 12]
regionUL <- unlist(region)

#Region and FB
plot(highx, highy, xlim = c(-1, 1), ylim = c(-1, 1), cex = 2, pch = c(22, 23)[regionUL], col = "white", bg = heat.colors(n = 296), bty = 'n', ann = FALSE, axes = FALSE)
axis(1, at = c(-1, 0.0, 1), labels = c(-1, 0.0, 1), col.axis = "black", las = 1, cex.axis = 1.5, lwd = 1)
axis(2, at = c(-1, 0.0, 1), labels = c(-1, 0.0, 1), col.axis = "black", las = 1, cex.axis = 1.5, lwd = 1, line = 0)
#title(main = "Cluster NMDS - High Risk", cex.main = 2.5, font.main = 2.5, line = 0.25, adj = 0.25)
#mtext("Component 2", side = 2, line = 2, cex = 2)  
#mtext("Component 1", side = 1, line = 3.5, cex = 2, adj = 0.375) 
#legend(.9, 0.75, cex = 1.5, border = 0, bty = "n", y.intersp = 1, x.intersp = 1, legend = c("Scotland", "Norway"), pch = c(15, 18), col = c("black"))
#legend(.9, 0.25, cex = 1.5, border = 0, bty = "n", y.intersp = 1, x.intersp = 1, legend = c("High ROS", "", "", "", "Low ROS"), pch = 15, col = heat.colors (n = 5))
#ordiellipse(f.NMDS3, fgroups, kind = "sd", show.groups = "1", label = F, col = "palevioletred2", lwd = 2, cex = 2)
#ordiellipse(f.NMDS3, fgroups, kind = "sd", show.groups = "2", label = F, col = "springgreen4",  lwd = 2, cex = 2)
#ordiellipse(f.NMDS3, fgroups, kind = "sd", show.groups = "3", label = F, col = "steelblue4", lwd = 2, cex = 2)
text(high.ord, "species", col = "black", labels = c("DEAD", "HERB", "LW", "FBD", "CBD"), font = 2, cex = 2)
#text(0, 0, cex = 1.5, labels = "(0, 0)")

high2.nmds <- recordPlot()

#Cluster and FB

#plot(highx, highy, xlim = c(-1, 1.5), ylim = c(-1.25, 1), cex = 2, pch = c(22, 23, 21, 24, 25, 22)[f[, 13]], col = c("white", "white", "white", "white", "white", "black")[f[, 13]], bg = heat.colors(n = 243)[highrosUL*75], bty = 'n', ann = FALSE, axes = FALSE)
#axis(1, at = c(-1, 0.0, 1), labels = c(-1, 0.0, 1), col.axis = "black", las = 1, cex.axis = 1.5, lwd = 1)
#axis(2, at = c(-1, 0.0, 1), labels = c(-1, 0.0, 1), col.axis = "black", las = 1, cex.axis = 1.5, lwd = 1, line = -1)
#title(main = "Cluster NMDS - High Risk", cex.main = 2.5, font.main = 2.5, line = 0.25, adj = 0.25)
#mtext("Component 2", side = 2, line = 2, cex = 2)  
#mtext("Component 1", side = 1, line = 3.5, cex = 2, adj = 0.375) 
#legend(.9, 1, cex = 1.5, border = 0, bty = "n", y.intersp = 1, x.intersp = 1, legend = c("Group 1", "Group 2", "Group 3", "Group 4", "Group 5", "Group 6"), pch = c(22, 23, 21, 24, 25, 22),  col = c("white", "white", "white", "white", "white", "black"), pt.bg = c("black", "black", "black", "black", "black", "white"))
#legend(.9, 0, cex = 1.5, border = 0, bty = "n", y.intersp = 1, x.intersp = 1, legend = c("High ROS", "", "", "", "Low ROS"), pch = 15, col = heat.colors (n = 5))
#ordiellipse(f.NMDS3, fgroups, kind = "sd", show.groups = "1", label = F, col = "palevioletred2", lwd = 2, cex = 2)
#ordiellipse(f.NMDS3, fgroups, kind = "sd", show.groups = "2", label = F, col = "springgreen4",  lwd = 2, cex = 2)
#ordiellipse(f.NMDS3, fgroups, kind = "sd", show.groups = "3", label = F, col = "steelblue4", lwd = 2, cex = 2)
#text(high.ord, "species", col = "black", labels = c("1", "2", "3", "4", "5"), font = 2, cex = 2)
#text(0, 0, cex = 1.5, labels = "(0, 0)")

#high3.nmds <- recordPlot()

#Cluster and EUNIS
EUNIS <- as.factor(f$EUNIS)
EUNIS
EUNIS.int <- as.integer(EUNIS)
EUNIS.int
  
plot(highx, highy, xlim = c(-1, 1), ylim = c(-1.25, 1), cex = 2, pch = 21, col = c("white", "white", "white", "white", "white", "white")[f$CLUSTER], bg = c("palevioletred2", "springgreen4", "steelblue4", "goldenrod", "magenta3", "skyblue2")[EUNIS.int], bty = 'n', ann = FALSE, axes = FALSE)
#plot(highx, highy, xlim = c(-1, 1), ylim = c(-1.25, 1), cex = 2, pch = c(22, 23, 21, 24, 25, 22)[f[, 13]], col = "white", bg = "white", bty = 'n', ann = FALSE, axes = FALSE)
axis(1, at = c(-1, 0.0, 1), labels = c(-1, 0.0, 1), col.axis = "black", las = 1, cex.axis = 1.5, lwd = 1)
axis(2, at = c(-1, 0.0, 1), labels = c(-1, 0.0, 1), col.axis = "black", las = 1, cex.axis = 1.5, lwd = 1, line = 0)
#title(main = "Cluster NMDS - High Risk", cex.main = 2.5, font.main = 2.5, line = 0.25, adj = 0.25)
#mtext("Component 2", side = 2, line = 2, cex = 2)  
#mtext("Component 1", side = 1, line = 3.5, cex = 2, adj = 0.375) 
#legend(.9, 1, cex = 1.5, border = 0, bty = "n", y.intersp = 1, x.intersp = 1, legend = c("Group 1", "Group 2", "Group 3", "Group 4", "Group 5", "Group 6"), pch = c(22, 23, 21, 24, 25, 22),  col = c("white", "white", "white", "white", "white", "black"), pt.bg = c("black", "black", "black", "black", "black", "white"))
#legend(.9, 0, cex = 1.5, border = 0, bty = "n", y.intersp = 1, x.intersp = 1, legend = c("H12", "H12b", "H8", "M19", "M20", "M25a"), pch = 15, col = c("palevioletred2", "springgreen4", "steelblue4", "goldenrod", "magenta3", "skyblue2"))
ordiellipse(high.NMDS3, EUNIS.int, kind = "sd", show.groups = "1", label = F, col = "palevioletred2", lwd = 2, cex = 2)
ordiellipse(high.NMDS3, EUNIS.int, kind = "sd", show.groups = "2", label = F, col = "springgreen4",  lwd = 2, cex = 2)
ordiellipse(high.NMDS3, EUNIS.int, kind = "sd", show.groups = "3", label = F, col = "steelblue4", lwd = 2, cex = 2)
ordiellipse(high.NMDS3, EUNIS.int, kind = "sd", show.groups = "4", label = F, col = "goldenrod", lwd = 2, cex = 2)
ordiellipse(high.NMDS3, EUNIS.int, kind = "sd", show.groups = "5", label = F, col = "magenta3", lwd = 2, cex = 2)
ordiellipse(high.NMDS3, EUNIS.int, kind = "sd", show.groups = "6", label = F, col = "skyblue2", lwd = 2, cex = 2)
text(high.ord, "species", col = "black", labels = c("DEAD", "HERB", "LW", "FBD", "CBD"), font = 2, cex = 2)
#text(0, 0, cex = 1.5, labels = "(0, 0)")

high4.nmds <- recordPlot()

#Cluster and Calluna
callclass <- as.factor(f$Stage)
callclass.int <- as.integer(callclass)

#plot(highx, highy, xlim = c(-1, 1.5), ylim = c(-1.25, 1), cex = 2, pch = c(22, 23, 21, 24, 25, 22)[f[, 13]], col = c("white", "white", "white", "white", "white", "black")[f[, 13]], bg = c("lightgoldenrod3", "red3", "darkorange2", "lightblue3", "springgreen4")[f[, 10]], bty = 'n', ann = FALSE, axes = FALSE)
plot(highx, highy, xlim = c(-1, 1), ylim = c(-1.25, 1), cex = 2, pch = 21, col = "white", bg = c("lightgoldenrod3", "red3", "darkorange2", "lightblue3", "springgreen4")[f$Stage], bty = 'n', ann = FALSE, axes = FALSE)
axis(1, at = c(-1, 0.0, 1), labels = c(-1, 0.0, 1), col.axis = "black", las = 1, cex.axis = 1.5, lwd = 1)
axis(2, at = c(-1, 0.0, 1), labels = c(-1, 0.0, 1), col.axis = "black", las = 1, cex.axis = 1.5, lwd = 1, line = 0)
#title(main = "Cluster NMDS - High Risk", cex.main = 2.5, font.main = 2.5, line = 0.25, adj = 0.25)
#mtext("Component 2", side = 2, line = 2, cex = 2)  
#mtext("Component 1", side = 1, line = 3.5, cex = 2, adj = 0.375) 
#legend(.9, 1, cex = 1.5, border = 0, bty = "n", y.intersp = 1, x.intersp = 1, legend = c("Group 1", "Group 2", "Group 3", "Group 4", "Group 5", "Group 6"), pch = c(22, 23, 21, 24, 25, 22),  col = c("white", "white", "white", "white", "white", "black"), pt.bg = c("black", "black", "black", "black", "black", "white"))
#legend(.9, 0, cex = 1.5, border = 0, bty = "n", y.intersp = 1, x.intersp = 1, legend = c("Pioneer", "Building", "Mature", "Degnerate", "Mire"), pch = 15, col = c("springgreen4", "lightgoldenrod3", "darkorange2", "red3", "lightblue3"))
#ordiellipse(f.NMDS3, fgroups, kind = "sd", show.groups = "1", label = F, col = "palevioletred2", lwd = 2, cex = 2)
#ordiellipse(f.NMDS3, fgroups, kind = "sd", show.groups = "2", label = F, col = "springgreen4",  lwd = 2, cex = 2)
#ordiellipse(f.NMDS3, fgroups, kind = "sd", show.groups = "3", label = F, col = "steelblue4", lwd = 2, cex = 2)
text(high.ord, "species", col = "black", labels = c("1", "2", "3", "4", "5"), font = 2, cex = 2)
#text(0, 0, cex = 1.5, labels = "(0, 0)")

high5.nmds <- recordPlot()

##facet (size = 11 in by 10 in)
ROScol <- turbo(n = 50)
all.f <- as.factor(all$ROS)
rank <- as.factor(as.numeric(cut(all$ROS, 50)))
rank
rank2 <- matrix(ncol = 2, nrow = 888)
rank2[, 1] <- 1:888
rank2[, 2] <- rank

max(highx)
min(highx)
max(highy)
min(highy)

par(mfrow = c(2, 2), mai = c(0.4, 0.4, 0.4, 0.3), oma = c(0, 0, 4, 0))

plot(highx, highy, xlim = c(-1, 1), ylim = c(-1.35, 1), cex = 2, pch = c(21, 22, 23, 24)[as.factor(regionUL)], col = "white", bg = c("lightgoldenrod3", "red3", "darkorange2", "lightblue3", "steelblue4")[callclass], bty = 'o', ann = FALSE, xaxt = "n", yaxt = "n")
axis(1, at = c(-1, 0.0, 1), labels = c(-1, 0.0, 1), col.axis = "black", las = 1, cex.axis = 1.5, lwd = 1)
axis(2, at = c(-1, 0.0, 1), labels = c(-1, 0.0, 1), col.axis = "black", las = 1, cex.axis = 1.5, lwd = 1, line = 0)
title(main = "Calluna          ", cex.main = 1.5, font.main = 4)
title(main = "               Stage", cex.main = 1.5)

legend("bottomleft",  text.width = c(0.5, 0.5, 0.5), inset = c(0, 0.02), xpd = TRUE, horiz = TRUE, cex = 1.5, border = 0, bty = "n", y.intersp = .6, x.intersp = 0.3, legend = c("Pioneer", "Building", "Mature"), pch = 15, col = c("steelblue4", "lightgoldenrod3", "darkorange2"))
legend("bottomleft",  text.width = c(0.5, 0.5), inset = c(0, -0.06), xpd = TRUE, horiz = TRUE, cex = 1.5, border = 0, bty = "n", y.intersp = .6, x.intersp = 0.3, legend = c("Degenerate", "Mire"), pch = 15, col = c("red3", "lightblue3"))

legend("topleft", inset = c(-0.1, -0.09), xpd = TRUE, cex = 1.5, border = 0, bty = "n", legend = "A")

#plot(highx, highy, xlim = c(-1, 1), ylim = c(-1.25, 1), cex = 2, pch = c(22, 21)[high[, 1]], col = "white", bg = c("plum3", "cornflowerblue", "seagreen4", "red4", "olivedrab3", "cyan3")[f[, 11]], bty = 'o', ann = FALSE, xaxt = "n", yaxt = "n")
plot(highx, highy, xlim = c(-1, 1), ylim = c(-1.35, 1), cex = 2, pch = c(21, 22, 23, 24)[as.factor(regionUL)], col = "white", bg = "white", bty = 'o', ann = FALSE, xaxt = "n", yaxt = "n")
title(main = "EUNIS", cex.main = 1.5, font.main = 2.5)
axis(1, at = c(-1, 0.0, 1), labels = c(-1, 0.0, 1), col.axis = "black", las = 1, cex.axis = 1.5, lwd = 1)
axis(2, at = c(-1, 0.0, 1), labels = c(-1, 0.0, 1), col.axis = "black", las = 1, cex.axis = 1.5, lwd = 1, line = 0)
ordiellipse(high.NMDS3, EUNIS.int, kind = "sd", show.groups = "1", label = F, col = "palevioletred2", lwd = 1.5, cex = 2, draw = "polygon", alpha = 90)
ordiellipse(high.NMDS3, EUNIS.int, kind = "sd", show.groups = "2", label = F, col = "springgreen4", lwd = 1.5, cex = 2, draw = "polygon", alpha = 90)
ordiellipse(high.NMDS3, EUNIS.int, kind = "sd", show.groups = "3", label = F, col = "steelblue4", lwd = 1.5, cex = 2, draw = "polygon", alpha = 90)
ordiellipse(high.NMDS3, EUNIS.int, kind = "sd", show.groups = "4", label = F, col = "goldenrod", lwd = 1.5, cex = 2, draw = "polygon", alpha = 90)
ordiellipse(high.NMDS3, EUNIS.int, kind = "sd", show.groups = "5", label = F, col = "skyblue2", lwd = 1.5, cex = 2, draw = "polygon", alpha = 90)
ordiellipse(high.NMDS3, EUNIS.int, kind = "sd", show.groups = "6", label = F, col = "magenta3", lwd = 1.5, cex = 2, draw = "polygon", alpha = 90)

legend("bottomleft", text.width = c(0.5, 0.5, 0.5), inset = c(0, 0.02), xpd = TRUE, horiz = TRUE, cex = 1.5, border = 0, bty = "n", y.intersp = .6, x.intersp = 0.3, legend = c("D1.21", "D1.221", "D1.222"), pch = 15, col = c("palevioletred2", "springgreen4", "steelblue4"))
legend("bottomleft", text.width = c(0.5, 0.5, 0.5), inset = c(0, -0.06), xpd = TRUE, horiz = TRUE, cex = 1.5, border = 0, bty = "n", y.intersp = .6, x.intersp = 0.3, legend = c("F4.21(H12)", "F4.21(H12b)", "F4.23"), pch = 15, col = c("goldenrod", "skyblue2", "magenta3"))

legend("topleft", inset = c(-0.1, -0.09), xpd = TRUE, cex = 1.5, border = 0, bty = "n", legend = "B")

plot(highx, highy, xlim = c(-1, 1), ylim = c(-1.35, 1), cex = 2, pch = c(21, 22, 23, 24)[as.factor(regionUL)], col = "white", bg = "white", bty = 'o', ann = FALSE, xaxt = "n", yaxt = "n")
axis(1, at = c(-1, 0.0, 1), labels = c(-1, 0.0, 1), col.axis = "black", las = 1, cex.axis = 1.5, lwd = 1)
axis(2, at = c(-1, 0.0, 1), labels = c(-1, 0.0, 1), col.axis = "black", las = 1, cex.axis = 1.5, lwd = 1, line = 0)
title(main = "Fuel Type Clusters", cex.main = 1.5, font.main = 2.5)
ordiellipse(high.NMDS3, fgroups, kind = "sd", show.groups = "1", label = F, col = "palevioletred2", lwd = 1.5, cex = 2, draw = "polygon", alpha = 90)
ordiellipse(high.NMDS3, fgroups, kind = "sd", show.groups = "2", label = F, col = "springgreen4",  lwd = 1.5, cex = 2, draw = "polygon", alpha = 90)
ordiellipse(high.NMDS3, fgroups, kind = "sd", show.groups = "3", label = F, col = "steelblue4", lwd = 1.5, cex = 2, draw = "polygon", alpha = 90)
ordiellipse(high.NMDS3, fgroups, kind = "sd", show.groups = "4", label = F, col = "goldenrod", lwd = 1.5, cex = 2, draw = "polygon", alpha = 90)
ordiellipse(high.NMDS3, fgroups, kind = "sd", show.groups = "5", label = F, col = "magenta3", lwd = 1.5, cex = 2, draw = "polygon", alpha = 90)
ordiellipse(high.NMDS3, fgroups, kind = "sd", show.groups = "6", label = F, col = "skyblue2", lwd = 1.5, cex = 2, draw = "polygon", alpha = 90)
text(high.ord, "species", col = "black", labels = c("DEAD", "HERB", "LW", "FBD", "CBD"), font = 2, cex = 1.25)

legend("bottomleft", text.width = c(0.5, 0.5, 0.5), inset = c(0, 0.02), xpd = TRUE, horiz = TRUE, cex = 1.5, border = 0, bty = "n", y.intersp = .6, x.intersp = 0.3, legend = c("Mature", "L Build", "T Build"), pch = 15, col = c("palevioletred2", "springgreen4", "steelblue4"))
legend("bottomleft", text.width = c(0.5, 0.5, 0.5), inset = c(0, -0.06), xpd = TRUE, horiz = TRUE, cex = 1.5, border = 0, bty = "n", y.intersp = .6, x.intersp = 0.3, legend = c("E Build", "Build+", "Pioneer+"), pch = 15, col = c("goldenrod", "magenta3", "skyblue2"))

legend("topleft", inset = c(-0.1, -0.09), xpd = TRUE, cex = 1.5, border = 0, bty = "n", legend = "C")

plot(highx, highy, xlim = c(-1, 1), ylim = c(-1.35, 1), cex = 2, pch = c(21, 22, 23, 24)[as.factor(regionUL)], col = "white", bg = ROScol[rank[1:296]], bty = 'o', ann = FALSE, xaxt = "n", yaxt = "n")
title(main = "Rate of Spread", cex.main = 1.5, font.main = 2.5)
axis(1, at = c(-1, 0.0, 1), labels = c(-1, 0.0, 1), col.axis = "black", las = 1, cex.axis = 1.5, lwd = 1)
axis(2, at = c(-1, 0.0, 1), labels = c(-1, 0.0, 1), col.axis = "black", las = 1, cex.axis = 1.5, lwd = 1, line = 0)

max(highrosUL)
min(highrosUL)

#legend.scale(c(0.01, 18.18), col = viridis(n = 5, direction = -1), horizontal = TRUE, axis.args = list(cex.axis = 1.5))
titleROS <- expression("    0.28 to 24.63 m"~min^-1)
legend("bottomleft", inset = c(-0.17, 0.07), title = titleROS, xpd = TRUE, horiz = TRUE, cex = 1.5, pt.cex = 5, bty = "n", y.intersp = -0.15, x.intersp = 0, legend = c("", "", "", "", ""), pch = 15, col = turbo(n = 5))

legend("topleft", inset = c(-0.1, -0.09), xpd = TRUE, cex = 1.5, border = 0, bty = "n", legend = "D")

par(fig = c(0, 1, 0, 1), oma = c(0, 0, 0, 0), mar = c(0, 0, 0, 0), new = TRUE)

plot(0, 0, type = "n", bty = "n", xaxt = "n", yaxt = "n")

legend(-.69, 1.1, xpd = TRUE, horiz = TRUE, cex = 1.5, border = 0, bty = "n", y.intersp = 1, x.intersp = 1, legend = c("England", "Norway", "Scotland", "Wales"), pch = c(16, 15, 18, 17), col = c("black"))

#Med Plots
#Region and Cluster
med.ord <- ordiplot(med.NMDS3, type = "text")

medx <- med.NMDS3$points[, 1]
medy <- med.NMDS3$points[, 2]

#plot(medx, medy, xlim = c(-1, 1), ylim = c(-1.25, 1), cex = 2, pch = c(22, 23)[med[, 1]], col = "white", bg = c("palevioletred2", "springgreen4", "steelblue4", "goldenrod", "magenta3", "skyblue2")[f[, 13]], bty = 'n', ann = FALSE, axes = FALSE)
plot(medx, medy, xlim = c(-1, 1), ylim = c(-1.25, 1), cex = 2, pch = c(22, 23)[unlist(f[, 1])], col = "white", bg = "white", bty = 'n', ann = FALSE, axes = FALSE)
axis(1, at = c(-1, 0.0, 1), labels = c(-1, 0.0, 1), col.axis = "black", las = 1, cex.axis = 1.5, lwd = 1)
axis(2, at = c(-1, 0.0, 1), labels = c(-1, 0.0, 1), col.axis = "black", las = 1, cex.axis = 1.5, lwd = 1, line = 0)
#title(main = "Cluster NMDS - med Risk", cex.main = 2.5, font.main = 2.5, line = 0.25, adj = 0.25)
#mtext("Component 2", side = 2, line = 2, cex = 2)  
#mtext("Component 1", side = 1, line = 3.5, cex = 2, adj = 0.375) 
#legend(.9, 0.75, cex = 1.5, border = 0, bty = "n", y.intersp = 1, x.intersp = 1, legend = c("Scotland", "Norway"), pch = c(15, 18), col = c("black"))
#legend(.9, 0.25, cex = 1.5, border = 0, bty = "n", y.intersp = 1, x.intersp = 1, legend = c("Group 1", "Group 2", "Group 3", "Group 4", "Group 5", "Group 6"), pch = 15, col = c("palevioletred2", "springgreen4", "steelblue4", "goldenrod", "magenta3", "skyblue2"))
ordiellipse(med.NMDS3, fgroups, kind = "sd", show.groups = "1", label = F, col = "palevioletred2", lwd = 2, cex = 2)
ordiellipse(med.NMDS3, fgroups, kind = "sd", show.groups = "2", label = F, col = "springgreen4",  lwd = 2, cex = 2)
ordiellipse(med.NMDS3, fgroups, kind = "sd", show.groups = "3", label = F, col = "steelblue4", lwd = 2, cex = 2)
ordiellipse(med.NMDS3, fgroups, kind = "sd", show.groups = "4", label = F, col = "goldenrod", lwd = 2, cex = 2)
ordiellipse(med.NMDS3, fgroups, kind = "sd", show.groups = "5", label = F, col = "magenta3", lwd = 2, cex = 2)
ordiellipse(med.NMDS3, fgroups, kind = "sd", show.groups = "6", label = F, col = "skyblue2", lwd = 2, cex = 2)
text(med.ord, "species", col = "black", labels = c("DEAD", "HERB", "LW", "FBD", "CBD"), font = 2, cex = 1.5)
#text(0, 0, cex = 1.5, labels = "(0, 0)")

med1.nmds <- recordPlot()

region <- f[, 12]
regionUL <- unlist(region)

#Region and FB
plot(medx, medy, xlim = c(-1, 1), ylim = c(-1, 1), cex = 2, pch = c(22, 23)[regionUL], col = "white", bg = heat.colors(n = 296), bty = 'n', ann = FALSE, axes = FALSE)
axis(1, at = c(-1, 0.0, 1), labels = c(-1, 0.0, 1), col.axis = "black", las = 1, cex.axis = 1.5, lwd = 1)
axis(2, at = c(-1, 0.0, 1), labels = c(-1, 0.0, 1), col.axis = "black", las = 1, cex.axis = 1.5, lwd = 1, line = 0)
#title(main = "Cluster NMDS - med Risk", cex.main = 2.5, font.main = 2.5, line = 0.25, adj = 0.25)
#mtext("Component 2", side = 2, line = 2, cex = 2)  
#mtext("Component 1", side = 1, line = 3.5, cex = 2, adj = 0.375) 
#legend(.9, 0.75, cex = 1.5, border = 0, bty = "n", y.intersp = 1, x.intersp = 1, legend = c("Scotland", "Norway"), pch = c(15, 18), col = c("black"))
#legend(.9, 0.25, cex = 1.5, border = 0, bty = "n", y.intersp = 1, x.intersp = 1, legend = c("med ROS", "", "", "", "Low ROS"), pch = 15, col = heat.colors (n = 5))
#ordiellipse(f.NMDS3, fgroups, kind = "sd", show.groups = "1", label = F, col = "palevioletred2", lwd = 2, cex = 2)
#ordiellipse(f.NMDS3, fgroups, kind = "sd", show.groups = "2", label = F, col = "springgreen4",  lwd = 2, cex = 2)
#ordiellipse(f.NMDS3, fgroups, kind = "sd", show.groups = "3", label = F, col = "steelblue4", lwd = 2, cex = 2)
text(med.ord, "species", col = "black", labels = c("DEAD", "HERB", "LW", "FBD", "CBD"), font = 2, cex = 2)
#text(0, 0, cex = 1.5, labels = "(0, 0)")

med2.nmds <- recordPlot()

#Cluster and FB
#plot(medx, medy, xlim = c(-1, 1.5), ylim = c(-1.25, 1), cex = 2, pch = c(22, 23, 21, 24, 25, 22)[f[, 13]], col = c("white", "white", "white", "white", "white", "black")[f[, 13]], bg = heat.colors(n = 243)[medrosUL*75], bty = 'n', ann = FALSE, axes = FALSE)
#axis(1, at = c(-1, 0.0, 1), labels = c(-1, 0.0, 1), col.axis = "black", las = 1, cex.axis = 1.5, lwd = 1)
#axis(2, at = c(-1, 0.0, 1), labels = c(-1, 0.0, 1), col.axis = "black", las = 1, cex.axis = 1.5, lwd = 1, line = -1)
#title(main = "Cluster NMDS - med Risk", cex.main = 2.5, font.main = 2.5, line = 0.25, adj = 0.25)
#mtext("Component 2", side = 2, line = 2, cex = 2)  
#mtext("Component 1", side = 1, line = 3.5, cex = 2, adj = 0.375) 
#legend(.9, 1, cex = 1.5, border = 0, bty = "n", y.intersp = 1, x.intersp = 1, legend = c("Group 1", "Group 2", "Group 3", "Group 4", "Group 5", "Group 6"), pch = c(22, 23, 21, 24, 25, 22),  col = c("white", "white", "white", "white", "white", "black"), pt.bg = c("black", "black", "black", "black", "black", "white"))
#legend(.9, 0, cex = 1.5, border = 0, bty = "n", y.intersp = 1, x.intersp = 1, legend = c("med ROS", "", "", "", "Low ROS"), pch = 15, col = heat.colors (n = 5))
#ordiellipse(f.NMDS3, fgroups, kind = "sd", show.groups = "1", label = F, col = "palevioletred2", lwd = 2, cex = 2)
#ordiellipse(f.NMDS3, fgroups, kind = "sd", show.groups = "2", label = F, col = "springgreen4",  lwd = 2, cex = 2)
#ordiellipse(f.NMDS3, fgroups, kind = "sd", show.groups = "3", label = F, col = "steelblue4", lwd = 2, cex = 2)
#text(med.ord, "species", col = "black", labels = c("1", "2", "3", "4", "5"), font = 2, cex = 2)
#text(0, 0, cex = 1.5, labels = "(0, 0)")

#med3.nmds <- recordPlot()

#Cluster and EUNIS
EUNIS <- as.factor(f$EUNIS)
EUNIS.int <- as.integer(EUNIS)

plot(medx, medy, xlim = c(-1, 1), ylim = c(-1.25, 1), cex = 2, pch = 21, col = c("white", "white", "white", "white", "white", "white")[f$CLUSTER], bg = c("palevioletred2", "springgreen4", "steelblue4", "goldenrod", "magenta3", "skyblue2")[EUNIS.int], bty = 'n', ann = FALSE, axes = FALSE)
#plot(medx, medy, xlim = c(-1, 1), ylim = c(-1.25, 1), cex = 2, pch = c(22, 23, 21, 24, 25, 22)[f[, 13]], col = "white", bg = "white", bty = 'n', ann = FALSE, axes = FALSE)
axis(1, at = c(-1, 0.0, 1), labels = c(-1, 0.0, 1), col.axis = "black", las = 1, cex.axis = 1.5, lwd = 1)
axis(2, at = c(-1, 0.0, 1), labels = c(-1, 0.0, 1), col.axis = "black", las = 1, cex.axis = 1.5, lwd = 1, line = 0)
#title(main = "Cluster NMDS - med Risk", cex.main = 2.5, font.main = 2.5, line = 0.25, adj = 0.25)
#mtext("Component 2", side = 2, line = 2, cex = 2)  
#mtext("Component 1", side = 1, line = 3.5, cex = 2, adj = 0.375) 
#legend(.9, 1, cex = 1.5, border = 0, bty = "n", y.intersp = 1, x.intersp = 1, legend = c("Group 1", "Group 2", "Group 3", "Group 4", "Group 5", "Group 6"), pch = c(22, 23, 21, 24, 25, 22),  col = c("white", "white", "white", "white", "white", "black"), pt.bg = c("black", "black", "black", "black", "black", "white"))
#legend(.9, 0, cex = 1.5, border = 0, bty = "n", y.intersp = 1, x.intersp = 1, legend = c("H12", "H12b", "H8", "M19", "M20", "M25a"), pch = 15, col = c("palevioletred2", "springgreen4", "steelblue4", "goldenrod", "magenta3", "skyblue2"))
ordiellipse(med.NMDS3, EUNIS.int, kind = "sd", show.groups = "1", label = F, col = "palevioletred2", lwd = 2, cex = 2)
ordiellipse(med.NMDS3, EUNIS.int, kind = "sd", show.groups = "2", label = F, col = "springgreen4",  lwd = 2, cex = 2)
ordiellipse(med.NMDS3, EUNIS.int, kind = "sd", show.groups = "3", label = F, col = "steelblue4", lwd = 2, cex = 2)
ordiellipse(med.NMDS3, EUNIS.int, kind = "sd", show.groups = "4", label = F, col = "goldenrod", lwd = 2, cex = 2)
ordiellipse(med.NMDS3, EUNIS.int, kind = "sd", show.groups = "5", label = F, col = "magenta3", lwd = 2, cex = 2)
ordiellipse(med.NMDS3, EUNIS.int, kind = "sd", show.groups = "6", label = F, col = "skyblue2", lwd = 2, cex = 2)
text(med.ord, "species", col = "black", labels = c("DEAD", "HERB", "LW", "FBD", "CBD"), font = 2, cex = 2)
#text(0, 0, cex = 1.5, labels = "(0, 0)")

med4.nmds <- recordPlot()

#Cluster and Calluna
callclass <- as.factor(f$Stage)
callclass.int <- as.integer(callclass)

#plot(medx, medy, xlim = c(-1, 1.5), ylim = c(-1.25, 1), cex = 2, pch = c(22, 23, 21, 24, 25, 22)[f[, 13]], col = c("white", "white", "white", "white", "white", "black")[f[, 13]], bg = c("lightgoldenrod3", "red3", "darkorange2", "lightblue3", "springgreen4")[f[, 10]], bty = 'n', ann = FALSE, axes = FALSE)
plot(medx, medy, xlim = c(-1, 1), ylim = c(-1.25, 1), cex = 2, pch = 21, col = "white", bg = c("lightgoldenrod3", "red3", "darkorange2", "lightblue3", "springgreen4")[f$Stage], bty = 'n', ann = FALSE, axes = FALSE)
axis(1, at = c(-1, 0.0, 1), labels = c(-1, 0.0, 1), col.axis = "black", las = 1, cex.axis = 1.5, lwd = 1)
axis(2, at = c(-1, 0.0, 1), labels = c(-1, 0.0, 1), col.axis = "black", las = 1, cex.axis = 1.5, lwd = 1, line = 0)
#title(main = "Cluster NMDS - med Risk", cex.main = 2.5, font.main = 2.5, line = 0.25, adj = 0.25)
#mtext("Component 2", side = 2, line = 2, cex = 2)  
#mtext("Component 1", side = 1, line = 3.5, cex = 2, adj = 0.375) 
#legend(.9, 1, cex = 1.5, border = 0, bty = "n", y.intersp = 1, x.intersp = 1, legend = c("Group 1", "Group 2", "Group 3", "Group 4", "Group 5", "Group 6"), pch = c(22, 23, 21, 24, 25, 22),  col = c("white", "white", "white", "white", "white", "black"), pt.bg = c("black", "black", "black", "black", "black", "white"))
#legend(.9, 0, cex = 1.5, border = 0, bty = "n", y.intersp = 1, x.intersp = 1, legend = c("Pioneer", "Building", "Mature", "Degnerate", "Mire"), pch = 15, col = c("springgreen4", "lightgoldenrod3", "darkorange2", "red3", "lightblue3"))
#ordiellipse(f.NMDS3, fgroups, kind = "sd", show.groups = "1", label = F, col = "palevioletred2", lwd = 2, cex = 2)
#ordiellipse(f.NMDS3, fgroups, kind = "sd", show.groups = "2", label = F, col = "springgreen4",  lwd = 2, cex = 2)
#ordiellipse(f.NMDS3, fgroups, kind = "sd", show.groups = "3", label = F, col = "steelblue4", lwd = 2, cex = 2)
text(med.ord, "species", col = "black", labels = c("1", "2", "3", "4", "5"), font = 2, cex = 2)
#text(0, 0, cex = 1.5, labels = "(0, 0)")

med5.nmds <- recordPlot()

par(mfrow = c(2, 2), mai = c(0.4, 0.4, 0.4, 0.3), oma = c(0, 0, 4, 0))

plot(medx, medy, xlim = c(-1, 1), ylim = c(-1.35, 1), cex = 2, pch = c(21, 22, 23, 24)[as.factor(regionUL)], col = "white", bg = c("lightgoldenrod3", "red3", "darkorange2", "lightblue3", "steelblue4")[callclass], bty = 'o', ann = FALSE, xaxt = "n", yaxt = "n")
axis(1, at = c(-1, 0.0, 1), labels = c(-1, 0.0, 1), col.axis = "black", las = 1, cex.axis = 1.5, lwd = 1)
axis(2, at = c(-1, 0.0, 1), labels = c(-1, 0.0, 1), col.axis = "black", las = 1, cex.axis = 1.5, lwd = 1, line = 0)
title(main = "Calluna          ", cex.main = 1.5, font.main = 4)
title(main = "               Stage", cex.main = 1.5)

legend("bottomleft",  text.width = c(0.5, 0.5, 0.5), inset = c(0, 0.02), xpd = TRUE, horiz = TRUE, cex = 1.5, border = 0, bty = "n", y.intersp = .6, x.intersp = 0.3, legend = c("Pioneer", "Building", "Mature"), pch = 15, col = c("steelblue4", "lightgoldenrod3", "darkorange2"))
legend("bottomleft",  text.width = c(0.5, 0.5), inset = c(0, -0.06), xpd = TRUE, horiz = TRUE, cex = 1.5, border = 0, bty = "n", y.intersp = .6, x.intersp = 0.3, legend = c("Degenerate", "Mire"), pch = 15, col = c("red3", "lightblue3"))

legend("topleft", inset = c(-0.1, -0.09), xpd = TRUE, cex = 1.5, border = 0, bty = "n", legend = "A")

#plot(medx, medy, xlim = c(-1, 1), ylim = c(-1.25, 1), cex = 2, pch = c(22, 21)[med[, 1]], col = "white", bg = c("plum3", "cornflowerblue", "seagreen4", "red4", "olivedrab3", "cyan3")[f[, 11]], bty = 'o', ann = FALSE, xaxt = "n", yaxt = "n")
plot(medx, medy, xlim = c(-1, 1), ylim = c(-1.35, 1), cex = 2, pch = c(21, 22, 23, 24)[as.factor(regionUL)], col = "white", bg = "white", bty = 'o', ann = FALSE, xaxt = "n", yaxt = "n")
title(main = "EUNIS", cex.main = 1.5, font.main = 2.5)
axis(1, at = c(-1, 0.0, 1), labels = c(-1, 0.0, 1), col.axis = "black", las = 1, cex.axis = 1.5, lwd = 1)
axis(2, at = c(-1, 0.0, 1), labels = c(-1, 0.0, 1), col.axis = "black", las = 1, cex.axis = 1.5, lwd = 1, line = 0)
ordiellipse(med.NMDS3, EUNIS.int, kind = "sd", show.groups = "1", label = F, col = "palevioletred2", lwd = 1.5, cex = 2, draw = "polygon", alpha = 90)
ordiellipse(med.NMDS3, EUNIS.int, kind = "sd", show.groups = "2", label = F, col = "springgreen4", lwd = 1.5, cex = 2, draw = "polygon", alpha = 90)
ordiellipse(med.NMDS3, EUNIS.int, kind = "sd", show.groups = "3", label = F, col = "steelblue4", lwd = 1.5, cex = 2, draw = "polygon", alpha = 90)
ordiellipse(med.NMDS3, EUNIS.int, kind = "sd", show.groups = "4", label = F, col = "goldenrod", lwd = 1.5, cex = 2, draw = "polygon", alpha = 90)
ordiellipse(med.NMDS3, EUNIS.int, kind = "sd", show.groups = "5", label = F, col = "skyblue2", lwd = 1.5, cex = 2, draw = "polygon", alpha = 90)
ordiellipse(med.NMDS3, EUNIS.int, kind = "sd", show.groups = "6", label = F, col = "magenta3", lwd = 1.5, cex = 2, draw = "polygon", alpha = 90)

legend("bottomleft", text.width = c(0.5, 0.5, 0.5), inset = c(0, 0.02), xpd = TRUE, horiz = TRUE, cex = 1.5, border = 0, bty = "n", y.intersp = .6, x.intersp = 0.3, legend = c("D1.21", "D1.221", "D1.222"), pch = 15, col = c("palevioletred2", "springgreen4", "steelblue4"))
legend("bottomleft", text.width = c(0.5, 0.5, 0.5), inset = c(0, -0.06), xpd = TRUE, horiz = TRUE, cex = 1.5, border = 0, bty = "n", y.intersp = .6, x.intersp = 0.3, legend = c("F4.21(H12)", "F4.21(H12b)", "F4.23"), pch = 15, col = c("goldenrod", "skyblue2", "magenta3"))

legend("topleft", inset = c(-0.1, -0.09), xpd = TRUE, cex = 1.5, border = 0, bty = "n", legend = "B")

plot(medx, medy, xlim = c(-1, 1), ylim = c(-1.35, 1), cex = 2, pch = c(21, 22, 23, 24)[as.factor(regionUL)], col = "white", bg = "white", bty = 'o', ann = FALSE, xaxt = "n", yaxt = "n")
axis(1, at = c(-1, 0.0, 1), labels = c(-1, 0.0, 1), col.axis = "black", las = 1, cex.axis = 1.5, lwd = 1)
axis(2, at = c(-1, 0.0, 1), labels = c(-1, 0.0, 1), col.axis = "black", las = 1, cex.axis = 1.5, lwd = 1, line = 0)
title(main = "Fuel Type Clusters", cex.main = 1.5, font.main = 2.5)
ordiellipse(med.NMDS3, fgroups, kind = "sd", show.groups = "1", label = F, col = "palevioletred2", lwd = 1.5, cex = 2, draw = "polygon", alpha = 90)
ordiellipse(med.NMDS3, fgroups, kind = "sd", show.groups = "2", label = F, col = "springgreen4",  lwd = 1.5, cex = 2, draw = "polygon", alpha = 90)
ordiellipse(med.NMDS3, fgroups, kind = "sd", show.groups = "3", label = F, col = "steelblue4", lwd = 1.5, cex = 2, draw = "polygon", alpha = 90)
ordiellipse(med.NMDS3, fgroups, kind = "sd", show.groups = "4", label = F, col = "goldenrod", lwd = 1.5, cex = 2, draw = "polygon", alpha = 90)
ordiellipse(med.NMDS3, fgroups, kind = "sd", show.groups = "5", label = F, col = "magenta3", lwd = 1.5, cex = 2, draw = "polygon", alpha = 90)
ordiellipse(med.NMDS3, fgroups, kind = "sd", show.groups = "6", label = F, col = "skyblue2", lwd = 1.5, cex = 2, draw = "polygon", alpha = 90)
text(med.ord, "species", col = "black", labels = c("DEAD", "HERB", "LW", "FBD", "CBD"), font = 2, cex = 1.25)

legend("bottomleft", text.width = c(0.5, 0.5, 0.5), inset = c(0, 0.02), xpd = TRUE, horiz = TRUE, cex = 1.5, border = 0, bty = "n", y.intersp = .6, x.intersp = 0.3, legend = c("Mature", "L Build", "T Build"), pch = 15, col = c("palevioletred2", "springgreen4", "steelblue4"))
legend("bottomleft", text.width = c(0.5, 0.5, 0.5), inset = c(0, -0.06), xpd = TRUE, horiz = TRUE, cex = 1.5, border = 0, bty = "n", y.intersp = .6, x.intersp = 0.3, legend = c("E Build", "Build+", "Pioneer+"), pch = 15, col = c("goldenrod", "magenta3", "skyblue2"))

legend("topleft", inset = c(-0.1, -0.09), xpd = TRUE, cex = 1.5, border = 0, bty = "n", legend = "C")

plot(medx, medy, xlim = c(-1, 1), ylim = c(-1.35, 1), cex = 2, pch = c(21, 22, 23, 24)[as.factor(regionUL)], col = "white", bg = ROScol[rank[297:592]], bty = 'o', ann = FALSE, xaxt = "n", yaxt = "n")
title(main = "Rate of Spread", cex.main = 1.5, font.main = 2.5)
axis(1, at = c(-1, 0.0, 1), labels = c(-1, 0.0, 1), col.axis = "black", las = 1, cex.axis = 1.5, lwd = 1)
axis(2, at = c(-1, 0.0, 1), labels = c(-1, 0.0, 1), col.axis = "black", las = 1, cex.axis = 1.5, lwd = 1, line = 0)

max(medrosUL)
min(medrosUL)

#legend.scale(c(0.01, 18.18), col = viridis(n = 5, direction = -1), horizontal = TRUE, axis.args = list(cex.axis = 1.5))
titleROS <- expression("    0.28 to 24.63 m"~min^-1)
legend("bottomleft", inset = c(-0.17, 0.07), title = titleROS, xpd = TRUE, horiz = TRUE, cex = 1.5, pt.cex = 5, bty = "n", y.intersp = -0.15, x.intersp = 0, legend = c("", "", "", "", ""), pch = 15, col = turbo(n = 5))

legend("topleft", inset = c(-0.1, -0.09), xpd = TRUE, cex = 1.5, border = 0, bty = "n", legend = "D")

par(fig = c(0, 1, 0, 1), oma = c(0, 0, 0, 0), mar = c(0, 0, 0, 0), new = TRUE)

plot(0, 0, type = "n", bty = "n", xaxt = "n", yaxt = "n")

legend(-0.69, 1.1, xpd = TRUE, horiz = TRUE, cex = 1.5, border = 0, bty = "n", y.intersp = 1, x.intersp = 1, legend = c("England", "Norway", "Scotland", "Wales"), pch = c(16, 15, 18, 17), col = c("black"))

#Low Plots
#Region and Cluster
low.ord <- ordiplot(low.NMDS3, type = "text")

lowx <- low.NMDS3$points[, 1]
lowy <- low.NMDS3$points[, 2]

#plot(lowx, lowy, xlim = c(-1, 1), ylim = c(-1.25, 1), cex = 2, pch = c(22, 23)[low[, 1]], col = "white", bg = c("palevioletred2", "springgreen4", "steelblue4", "goldenrod", "magenta3", "skyblue2")[f[, 13]], bty = 'n', ann = FALSE, axes = FALSE)
plot(lowx, lowy, xlim = c(-1, 1), ylim = c(-1.25, 1), cex = 2, pch = c(22, 23)[unlist(f[, 1])], col = "white", bg = "white", bty = 'n', ann = FALSE, axes = FALSE)
axis(1, at = c(-1, 0.0, 1), labels = c(-1, 0.0, 1), col.axis = "black", las = 1, cex.axis = 1.5, lwd = 1)
axis(2, at = c(-1, 0.0, 1), labels = c(-1, 0.0, 1), col.axis = "black", las = 1, cex.axis = 1.5, lwd = 1, line = 0)
#title(main = "Cluster NMDS - low Risk", cex.main = 2.5, font.main = 2.5, line = 0.25, adj = 0.25)
#mtext("Component 2", side = 2, line = 2, cex = 2)  
#mtext("Component 1", side = 1, line = 3.5, cex = 2, adj = 0.375) 
#legend(.9, 0.75, cex = 1.5, border = 0, bty = "n", y.intersp = 1, x.intersp = 1, legend = c("Scotland", "Norway"), pch = c(15, 18), col = c("black"))
#legend(.9, 0.25, cex = 1.5, border = 0, bty = "n", y.intersp = 1, x.intersp = 1, legend = c("Group 1", "Group 2", "Group 3", "Group 4", "Group 5", "Group 6"), pch = 15, col = c("palevioletred2", "springgreen4", "steelblue4", "goldenrod", "magenta3", "skyblue2"))
ordiellipse(low.NMDS3, fgroups, kind = "sd", show.groups = "1", label = F, col = "palevioletred2", lwd = 2, cex = 2)
ordiellipse(low.NMDS3, fgroups, kind = "sd", show.groups = "2", label = F, col = "springgreen4",  lwd = 2, cex = 2)
ordiellipse(low.NMDS3, fgroups, kind = "sd", show.groups = "3", label = F, col = "steelblue4", lwd = 2, cex = 2)
ordiellipse(low.NMDS3, fgroups, kind = "sd", show.groups = "4", label = F, col = "goldenrod", lwd = 2, cex = 2)
ordiellipse(low.NMDS3, fgroups, kind = "sd", show.groups = "5", label = F, col = "magenta3", lwd = 2, cex = 2)
ordiellipse(low.NMDS3, fgroups, kind = "sd", show.groups = "6", label = F, col = "skyblue2", lwd = 2, cex = 2)
text(low.ord, "species", col = "black", labels = c("DEAD", "HERB", "LW", "FBD", "CBD"), font = 2, cex = 1.5)
#text(0, 0, cex = 1.5, labels = "(0, 0)")

low1.nmds <- recordPlot()

region <- f[, 12]
regionUL <- unlist(region)

#Region and FB
plot(lowx, lowy, xlim = c(-1, 1), ylim = c(-1, 1), cex = 2, pch = c(22, 23)[regionUL], col = "white", bg = heat.colors(n = 296), bty = 'n', ann = FALSE, axes = FALSE)
axis(1, at = c(-1, 0.0, 1), labels = c(-1, 0.0, 1), col.axis = "black", las = 1, cex.axis = 1.5, lwd = 1)
axis(2, at = c(-1, 0.0, 1), labels = c(-1, 0.0, 1), col.axis = "black", las = 1, cex.axis = 1.5, lwd = 1, line = 0)
#title(main = "Cluster NMDS - low Risk", cex.main = 2.5, font.main = 2.5, line = 0.25, adj = 0.25)
#mtext("Component 2", side = 2, line = 2, cex = 2)  
#mtext("Component 1", side = 1, line = 3.5, cex = 2, adj = 0.375) 
#legend(.9, 0.75, cex = 1.5, border = 0, bty = "n", y.intersp = 1, x.intersp = 1, legend = c("Scotland", "Norway"), pch = c(15, 18), col = c("black"))
#legend(.9, 0.25, cex = 1.5, border = 0, bty = "n", y.intersp = 1, x.intersp = 1, legend = c("low ROS", "", "", "", "Low ROS"), pch = 15, col = heat.colors (n = 5))
#ordiellipse(f.NMDS3, fgroups, kind = "sd", show.groups = "1", label = F, col = "palevioletred2", lwd = 2, cex = 2)
#ordiellipse(f.NMDS3, fgroups, kind = "sd", show.groups = "2", label = F, col = "springgreen4",  lwd = 2, cex = 2)
#ordiellipse(f.NMDS3, fgroups, kind = "sd", show.groups = "3", label = F, col = "steelblue4", lwd = 2, cex = 2)
text(low.ord, "species", col = "black", labels = c("DEAD", "HERB", "LW", "FBD", "CBD"), font = 2, cex = 2)
#text(0, 0, cex = 1.5, labels = "(0, 0)")

low2.nmds <- recordPlot()

#Cluster and FB
#plot(lowx, lowy, xlim = c(-1, 1.5), ylim = c(-1.25, 1), cex = 2, pch = c(22, 23, 21, 24, 25, 22)[f[, 13]], col = c("white", "white", "white", "white", "white", "black")[f[, 13]], bg = heat.colors(n = 243)[lowrosUL*75], bty = 'n', ann = FALSE, axes = FALSE)
#axis(1, at = c(-1, 0.0, 1), labels = c(-1, 0.0, 1), col.axis = "black", las = 1, cex.axis = 1.5, lwd = 1)
#axis(2, at = c(-1, 0.0, 1), labels = c(-1, 0.0, 1), col.axis = "black", las = 1, cex.axis = 1.5, lwd = 1, line = -1)
#title(main = "Cluster NMDS - low Risk", cex.main = 2.5, font.main = 2.5, line = 0.25, adj = 0.25)
#mtext("Component 2", side = 2, line = 2, cex = 2)  
#mtext("Component 1", side = 1, line = 3.5, cex = 2, adj = 0.375) 
#legend(.9, 1, cex = 1.5, border = 0, bty = "n", y.intersp = 1, x.intersp = 1, legend = c("Group 1", "Group 2", "Group 3", "Group 4", "Group 5", "Group 6"), pch = c(22, 23, 21, 24, 25, 22),  col = c("white", "white", "white", "white", "white", "black"), pt.bg = c("black", "black", "black", "black", "black", "white"))
#legend(.9, 0, cex = 1.5, border = 0, bty = "n", y.intersp = 1, x.intersp = 1, legend = c("low ROS", "", "", "", "Low ROS"), pch = 15, col = heat.colors (n = 5))
#ordiellipse(f.NMDS3, fgroups, kind = "sd", show.groups = "1", label = F, col = "palevioletred2", lwd = 2, cex = 2)
#ordiellipse(f.NMDS3, fgroups, kind = "sd", show.groups = "2", label = F, col = "springgreen4",  lwd = 2, cex = 2)
#ordiellipse(f.NMDS3, fgroups, kind = "sd", show.groups = "3", label = F, col = "steelblue4", lwd = 2, cex = 2)
#text(low.ord, "species", col = "black", labels = c("1", "2", "3", "4", "5"), font = 2, cex = 2)
#text(0, 0, cex = 1.5, labels = "(0, 0)")

#low3.nmds <- recordPlot()

#Cluster and EUNIS
EUNIS <- as.factor(f$EUNIS)
EUNIS.int <- as.integer(EUNIS)

plot(lowx, lowy, xlim = c(-1, 1), ylim = c(-1.25, 1), cex = 2, pch = 21, col = c("white", "white", "white", "white", "white", "white")[f$CLUSTER], bg = c("palevioletred2", "springgreen4", "steelblue4", "goldenrod", "magenta3", "skyblue2")[EUNIS.int], bty = 'n', ann = FALSE, axes = FALSE)
#plot(lowx, lowy, xlim = c(-1, 1), ylim = c(-1.25, 1), cex = 2, pch = c(22, 23, 21, 24, 25, 22)[f[, 13]], col = "white", bg = "white", bty = 'n', ann = FALSE, axes = FALSE)
axis(1, at = c(-1, 0.0, 1), labels = c(-1, 0.0, 1), col.axis = "black", las = 1, cex.axis = 1.5, lwd = 1)
axis(2, at = c(-1, 0.0, 1), labels = c(-1, 0.0, 1), col.axis = "black", las = 1, cex.axis = 1.5, lwd = 1, line = 0)
#title(main = "Cluster NMDS - low Risk", cex.main = 2.5, font.main = 2.5, line = 0.25, adj = 0.25)
#mtext("Component 2", side = 2, line = 2, cex = 2)  
#mtext("Component 1", side = 1, line = 3.5, cex = 2, adj = 0.375) 
#legend(.9, 1, cex = 1.5, border = 0, bty = "n", y.intersp = 1, x.intersp = 1, legend = c("Group 1", "Group 2", "Group 3", "Group 4", "Group 5", "Group 6"), pch = c(22, 23, 21, 24, 25, 22),  col = c("white", "white", "white", "white", "white", "black"), pt.bg = c("black", "black", "black", "black", "black", "white"))
#legend(.9, 0, cex = 1.5, border = 0, bty = "n", y.intersp = 1, x.intersp = 1, legend = c("H12", "H12b", "H8", "M19", "M20", "M25a"), pch = 15, col = c("palevioletred2", "springgreen4", "steelblue4", "goldenrod", "magenta3", "skyblue2"))
ordiellipse(low.NMDS3, EUNIS.int, kind = "sd", show.groups = "1", label = F, col = "palevioletred2", lwd = 2, cex = 2)
ordiellipse(low.NMDS3, EUNIS.int, kind = "sd", show.groups = "2", label = F, col = "springgreen4",  lwd = 2, cex = 2)
ordiellipse(low.NMDS3, EUNIS.int, kind = "sd", show.groups = "3", label = F, col = "steelblue4", lwd = 2, cex = 2)
ordiellipse(low.NMDS3, EUNIS.int, kind = "sd", show.groups = "4", label = F, col = "goldenrod", lwd = 2, cex = 2)
ordiellipse(low.NMDS3, EUNIS.int, kind = "sd", show.groups = "5", label = F, col = "magenta3", lwd = 2, cex = 2)
ordiellipse(low.NMDS3, EUNIS.int, kind = "sd", show.groups = "6", label = F, col = "skyblue2", lwd = 2, cex = 2)
text(low.ord, "species", col = "black", labels = c("DEAD", "HERB", "LW", "FBD", "CBD"), font = 2, cex = 2)
#text(0, 0, cex = 1.5, labels = "(0, 0)")

low4.nmds <- recordPlot()

#Cluster and Calluna
callclass <- as.factor(f$Stage)
callclass.int <- as.integer(callclass)

#plot(lowx, lowy, xlim = c(-1, 1.5), ylim = c(-1.25, 1), cex = 2, pch = c(22, 23, 21, 24, 25, 22)[f[, 13]], col = c("white", "white", "white", "white", "white", "black")[f[, 13]], bg = c("lightgoldenrod3", "red3", "darkorange2", "lightblue3", "springgreen4")[f[, 10]], bty = 'n', ann = FALSE, axes = FALSE)
plot(lowx, lowy, xlim = c(-1, 1), ylim = c(-1.25, 1), cex = 2, pch = 21, col = "white", bg = c("lightgoldenrod3", "red3", "darkorange2", "lightblue3", "springgreen4")[f$Stage], bty = 'n', ann = FALSE, axes = FALSE)
axis(1, at = c(-1, 0.0, 1), labels = c(-1, 0.0, 1), col.axis = "black", las = 1, cex.axis = 1.5, lwd = 1)
axis(2, at = c(-1, 0.0, 1), labels = c(-1, 0.0, 1), col.axis = "black", las = 1, cex.axis = 1.5, lwd = 1, line = 0)
#title(main = "Cluster NMDS - low Risk", cex.main = 2.5, font.main = 2.5, line = 0.25, adj = 0.25)
#mtext("Component 2", side = 2, line = 2, cex = 2)  
#mtext("Component 1", side = 1, line = 3.5, cex = 2, adj = 0.375) 
#legend(.9, 1, cex = 1.5, border = 0, bty = "n", y.intersp = 1, x.intersp = 1, legend = c("Group 1", "Group 2", "Group 3", "Group 4", "Group 5", "Group 6"), pch = c(22, 23, 21, 24, 25, 22),  col = c("white", "white", "white", "white", "white", "black"), pt.bg = c("black", "black", "black", "black", "black", "white"))
#legend(.9, 0, cex = 1.5, border = 0, bty = "n", y.intersp = 1, x.intersp = 1, legend = c("Pioneer", "Building", "Mature", "Degnerate", "Mire"), pch = 15, col = c("springgreen4", "lightgoldenrod3", "darkorange2", "red3", "lightblue3"))
#ordiellipse(f.NMDS3, fgroups, kind = "sd", show.groups = "1", label = F, col = "palevioletred2", lwd = 2, cex = 2)
#ordiellipse(f.NMDS3, fgroups, kind = "sd", show.groups = "2", label = F, col = "springgreen4",  lwd = 2, cex = 2)
#ordiellipse(f.NMDS3, fgroups, kind = "sd", show.groups = "3", label = F, col = "steelblue4", lwd = 2, cex = 2)
text(low.ord, "species", col = "black", labels = c("1", "2", "3", "4", "5"), font = 2, cex = 2)
#text(0, 0, cex = 1.5, labels = "(0, 0)")

low5.nmds <- recordPlot()

par(mfrow = c(2, 2), mai = c(0.4, 0.4, 0.4, 0.3), oma = c(0, 0, 4, 0))

plot(lowx, lowy, xlim = c(-1, 1), ylim = c(-1.35, 1), cex = 2, pch = c(21, 22, 23, 24)[as.factor(regionUL)], col = "white", bg = c("lightgoldenrod3", "red3", "darkorange2", "lightblue3", "steelblue4")[callclass], bty = 'o', ann = FALSE, xaxt = "n", yaxt = "n")
axis(1, at = c(-1, 0.0, 1), labels = c(-1, 0.0, 1), col.axis = "black", las = 1, cex.axis = 1.5, lwd = 1)
axis(2, at = c(-1, 0.0, 1), labels = c(-1, 0.0, 1), col.axis = "black", las = 1, cex.axis = 1.5, lwd = 1, line = 0)
title(main = "Calluna          ", cex.main = 1.5, font.main = 4)
title(main = "               Stage", cex.main = 1.5)

legend("bottomleft",  text.width = c(0.5, 0.5, 0.5), inset = c(0, 0.02), xpd = TRUE, horiz = TRUE, cex = 1.5, border = 0, bty = "n", y.intersp = .6, x.intersp = 0.3, legend = c("Pioneer", "Building", "Mature"), pch = 15, col = c("steelblue4", "lightgoldenrod3", "darkorange2"))
legend("bottomleft",  text.width = c(0.5, 0.5), inset = c(0, -0.06), xpd = TRUE, horiz = TRUE, cex = 1.5, border = 0, bty = "n", y.intersp = .6, x.intersp = 0.3, legend = c("Degenerate", "Mire"), pch = 15, col = c("red3", "lightblue3"))

legend("topleft", inset = c(-0.1, -0.09), xpd = TRUE, cex = 1.5, border = 0, bty = "n", legend = "A")

#plot(lowx, lowy, xlim = c(-1, 1), ylim = c(-1.25, 1), cex = 2, pch = c(22, 21)[low[, 1]], col = "white", bg = c("plum3", "cornflowerblue", "seagreen4", "red4", "olivedrab3", "cyan3")[f[, 11]], bty = 'o', ann = FALSE, xaxt = "n", yaxt = "n")
plot(lowx, lowy, xlim = c(-1, 1), ylim = c(-1.35, 1), cex = 2, pch = c(21, 22, 23, 24)[as.factor(regionUL)], col = "white", bg = "white", bty = 'o', ann = FALSE, xaxt = "n", yaxt = "n")
title(main = "EUNIS", cex.main = 1.5, font.main = 2.5)
axis(1, at = c(-1, 0.0, 1), labels = c(-1, 0.0, 1), col.axis = "black", las = 1, cex.axis = 1.5, lwd = 1)
axis(2, at = c(-1, 0.0, 1), labels = c(-1, 0.0, 1), col.axis = "black", las = 1, cex.axis = 1.5, lwd = 1, line = 0)
ordiellipse(low.NMDS3, EUNIS.int, kind = "sd", show.groups = "1", label = F, col = "palevioletred2", lwd = 1.5, cex = 2, draw = "polygon", alpha = 90)
ordiellipse(low.NMDS3, EUNIS.int, kind = "sd", show.groups = "2", label = F, col = "springgreen4", lwd = 1.5, cex = 2, draw = "polygon", alpha = 90)
ordiellipse(low.NMDS3, EUNIS.int, kind = "sd", show.groups = "3", label = F, col = "steelblue4", lwd = 1.5, cex = 2, draw = "polygon", alpha = 90)
ordiellipse(low.NMDS3, EUNIS.int, kind = "sd", show.groups = "4", label = F, col = "goldenrod", lwd = 1.5, cex = 2, draw = "polygon", alpha = 90)
ordiellipse(low.NMDS3, EUNIS.int, kind = "sd", show.groups = "5", label = F, col = "skyblue2", lwd = 1.5, cex = 2, draw = "polygon", alpha = 90)
ordiellipse(low.NMDS3, EUNIS.int, kind = "sd", show.groups = "6", label = F, col = "magenta3", lwd = 1.5, cex = 2, draw = "polygon", alpha = 90)

legend("bottomleft", text.width = c(0.5, 0.5, 0.5), inset = c(0, 0.02), xpd = TRUE, horiz = TRUE, cex = 1.5, border = 0, bty = "n", y.intersp = .6, x.intersp = 0.3, legend = c("D1.21", "D1.221", "D1.222"), pch = 15, col = c("palevioletred2", "springgreen4", "steelblue4"))
legend("bottomleft", text.width = c(0.5, 0.5, 0.5), inset = c(0, -0.06), xpd = TRUE, horiz = TRUE, cex = 1.5, border = 0, bty = "n", y.intersp = .6, x.intersp = 0.3, legend = c("F4.21(H12)", "F4.21(H12b)", "F4.23"), pch = 15, col = c("goldenrod", "skyblue2", "magenta3"))

legend("topleft", inset = c(-0.1, -0.09), xpd = TRUE, cex = 1.5, border = 0, bty = "n", legend = "B")

plot(lowx, lowy, xlim = c(-1, 1), ylim = c(-1.35, 1), cex = 2, pch = c(21, 22, 23, 24)[as.factor(regionUL)], col = "white", bg = "white", bty = 'o', ann = FALSE, xaxt = "n", yaxt = "n")
axis(1, at = c(-1, 0.0, 1), labels = c(-1, 0.0, 1), col.axis = "black", las = 1, cex.axis = 1.5, lwd = 1)
axis(2, at = c(-1, 0.0, 1), labels = c(-1, 0.0, 1), col.axis = "black", las = 1, cex.axis = 1.5, lwd = 1, line = 0)
title(main = "Fuel Type Clusters", cex.main = 1.5, font.main = 2.5)
ordiellipse(low.NMDS3, fgroups, kind = "sd", show.groups = "1", label = F, col = "palevioletred2", lwd = 1.5, cex = 2, draw = "polygon", alpha = 90)
ordiellipse(low.NMDS3, fgroups, kind = "sd", show.groups = "2", label = F, col = "springgreen4",  lwd = 1.5, cex = 2, draw = "polygon", alpha = 90)
ordiellipse(low.NMDS3, fgroups, kind = "sd", show.groups = "3", label = F, col = "steelblue4", lwd = 1.5, cex = 2, draw = "polygon", alpha = 90)
ordiellipse(low.NMDS3, fgroups, kind = "sd", show.groups = "4", label = F, col = "goldenrod", lwd = 1.5, cex = 2, draw = "polygon", alpha = 90)
ordiellipse(low.NMDS3, fgroups, kind = "sd", show.groups = "5", label = F, col = "magenta3", lwd = 1.5, cex = 2, draw = "polygon", alpha = 90)
ordiellipse(low.NMDS3, fgroups, kind = "sd", show.groups = "6", label = F, col = "skyblue2", lwd = 1.5, cex = 2, draw = "polygon", alpha = 90)
text(low.ord, "species", col = "black", labels = c("DEAD", "HERB", "LW", "FBD", "CBD"), font = 2, cex = 1.25)

legend("bottomleft", text.width = c(0.5, 0.5, 0.5), inset = c(0, 0.02), xpd = TRUE, horiz = TRUE, cex = 1.5, border = 0, bty = "n", y.intersp = .6, x.intersp = 0.3, legend = c("Mature", "L Build", "T Build"), pch = 15, col = c("palevioletred2", "springgreen4", "steelblue4"))
legend("bottomleft", text.width = c(0.5, 0.5, 0.5), inset = c(0, -0.06), xpd = TRUE, horiz = TRUE, cex = 1.5, border = 0, bty = "n", y.intersp = .6, x.intersp = 0.3, legend = c("E Build", "Build+", "Pioneer+"), pch = 15, col = c("goldenrod", "magenta3", "skyblue2"))

legend("topleft", inset = c(-0.1, -0.09), xpd = TRUE, cex = 1.5, border = 0, bty = "n", legend = "C")

plot(lowx, lowy, xlim = c(-1, 1), ylim = c(-1.35, 1), cex = 2, pch = c(21, 22, 23, 24)[as.factor(regionUL)], col = "white", bg = ROScol[rank[593:888]], bty = 'o', ann = FALSE, xaxt = "n", yaxt = "n")
title(main = "Rate of Spread", cex.main = 1.5, font.main = 2.5)
axis(1, at = c(-1, 0.0, 1), labels = c(-1, 0.0, 1), col.axis = "black", las = 1, cex.axis = 1.5, lwd = 1)
axis(2, at = c(-1, 0.0, 1), labels = c(-1, 0.0, 1), col.axis = "black", las = 1, cex.axis = 1.5, lwd = 1, line = 0)

max(lowrosUL)
min(lowrosUL)

#legend.scale(c(0.01, 18.18), col = viridis(n = 5, direction = -1), horizontal = TRUE, axis.args = list(cex.axis = 1.5))
titleROS <- expression("    0.28 to 24.63 m"~min^-1)
legend("bottomleft", inset = c(-0.17, 0.07), title = titleROS, xpd = TRUE, horiz = TRUE, cex = 1.5, pt.cex = 5, bty = "n", y.intersp = -0.15, x.intersp = 0, legend = c("", "", "", "", ""), pch = 15, col = turbo(n = 5))

legend("topleft", inset = c(-0.1, -0.09), xpd = TRUE, cex = 1.5, border = 0, bty = "n", legend = "D")

par(fig = c(0, 1, 0, 1), oma = c(0, 0, 0, 0), mar = c(0, 0, 0, 0), new = TRUE)

plot(0, 0, type = "n", bty = "n", xaxt = "n", yaxt = "n")

legend(-0.69, 1.1, xpd = TRUE, horiz = TRUE, cex = 1.5, border = 0, bty = "n", y.intersp = 1, x.intersp = 1, legend = c("England", "Norway", "Scotland", "Wales"), pch = c(16, 15, 18, 17), col = c("black"))

#########################
#Decision Trees Analysis#
#########################

data <- read_xlsx("2.AllData_minsavage-davis_fuelmodels.xlsx", sheet = "Cluster")
index <- c(1, 2, 3, 4)
clust <- c("Mature", "L Build", "T Build", "E Build", "P Build+")
stage <- c("Pioneer","Building","Mature","Degenerate","Mire")

data$NewName <- factor(data$NewName, levels = clust)
as.factor(data$NewName)

data$Stage <- factor(data$Stage, levels = stage)
as.factor(data$Stage)

data.t <- data[, c(11:18, 28)]

callstage <- as.factor(data$Stage)
callstage

#Predictions based on all data
set.seed(100)

fit <- rpart(as.factor(NewName)~Country+EUNIS+Stage+MossH+FBDm, method = "class", data = data.t)

printcp(fit)
plot(fit)
prp(fit, cex = 1.25)
label <- c("", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "")
text(fit, label)
summary(fit)

predict.fit <- fit %>% predict(data.t, type = "class")
head(predict.fit)

mean(predict.fit == data.t$NewName)

#Prune le tree
set.seed(100)

modelp <- train(as.factor(NewName)~Country+EUNIS+Stage+MossH+FBDm, data = data.t, method = "rpart", trControl = trainControl("cv", number = 10), tuneLength = 10)

plot(modelp)

modelp$bestTune
prp(modelp$finalModel, yesno = 0)

predict.fitp <- modelp %>% predict(data.t)
mean(predict.fitp == data.t$NewName)

labels()

#Create a training and test set to compare
set.seed(100)

training.s <- data.t$NewName %>% createDataPartition(p = 0.8, list = FALSE)

train.d <- data.t[training.s, ]
test.d <- data.t[-training.s, ]

fit2 <- rpart(as.factor(NewName)~Country+EUNIS+Stage+MossH+FBDm, method = "class", data = train.d)

printcp(fit2)
prp(fit2)
text(fit2)
summary(fit2)

predict.fit2 <- fit2 %>% predict(test.d, type = "class")
head(predict.fit2)

mean(predict.fit2 == test.d$NewName)

#Prune le tree
set.seed(100)

model3 <- train(as.factor(NewName)~Country+EUNIS+Stage+MossH+FBDm, data = train.d, method = "rpart", trControl = trainControl("cv", number = 10), tuneLength = 10)

plot(model3)

model3$bestTune

plot(model3$finalModel)
prp(model3$finalModel, cex = 1.25)

predict.fit3 <- model3 %>% predict(test.d)
mean(predict.fit3 == test.d$NewName)

######################
#Sensitivity Analysis#
######################

#data <- read.csv(file.choose(), header = TRUE)

data.s <- read_xlsx("2.AllData_minsavage-davis_fuelmodels.xlsx", sheet = "ClusterComb")

barplot(data.s$dead90~data.s$Name, xlab = "", ylab = "1 Hr Fuels (kg/m^2)")
barplot(data.s$LvWoody~data.s$Name, xlab = "", ylab = "Live Woody Fuels (kg/m^2)")
barplot(data.s$FBDm~data.s$Name, xlab = "", ylab = "FBD (m)")

totros <- matrix(ncol = 5, nrow = 300)
colnames(totros) <- c("ROS", "WS", "DEADFMC", "LIVEWOODFMC", "MODEL")

MODEL <- "S"
SAV <- c(9560,	8810,	8810,	8810,	1000)
MOE <- 30
HEAT <- c(20810,	20810,	20810,	20810,	20810)
MOIST.D <- c(15, 15,	15)
MOIST.L <- c(60, 60)
WIND <- 0
SLOPE <- 0

tick <- 1

ros.mat <- data.frame()

for(i in 1:5){

WIND <- 0  
  
  for (j in 1:10){
  
    
    
    for (k in 1:nrow(data.s)){
      
    ros.mat[tick, 1] <- "S"
    ros.mat[tick, 2:6] <- c((data.s[k, 11]+data.s[k, 5])*11.0231, 0, 0, 0, data.s[k, 6]*11.0231)
    ros.mat[tick, 7:11] <- SAV
    ros.mat[tick, 12] <- data.s[k, 7]
    ros.mat[tick, 13] <- MOE
    ros.mat[tick, 14:18] <- HEAT
    ros.mat[tick, 19:21] <- MOIST.D
    ros.mat[tick, 22:23] <- MOIST.L
    ros.mat[tick, 24] <- WIND
    ros.mat[tick, 25] <- 0
    
    ros.mat[tick, 26] <- data.s[k, 2]
    
    tick <- tick + 1
    
    }
    
  WIND <- WIND + 1  
  }

MOIST.D <- MOIST.D + 2
MOIST.L <- MOIST.L + 7 

}

ros <- ros(ros.mat[, 1], ros.mat[, 2:6], ros.mat[, 7:11], ros.mat[, 12], ros.mat[, 13], ros.mat[, 14:18], ros.mat[, 19:23], ros.mat[, 24], ros.mat[, 25])

ros.vec <- ros$`ROS [m/min]`

fullmat <- cbind(ros.mat, ros.vec, ros.mat[, 19])

colnames(fullmat) <- c("ModelType", "1-hrLoad", "10-hrLoad", "100-hrLoad", "LiveHerbLoad", "LiveWoodyLoad", "1-hrSAV", "10-hrSAV", "100-hrSAV", "LiveHerbSAV", "LiveWoodySAV", "FBD", "MOE", "1-hrHC", "10-hrHC", "100-hrHC", "Live HerbHC", "Live WoodyHC", "1-hrFMC", "10-hrFMC", "100-hrFMC", "LiveHerbFMC", "LiveWoodyFMC", "WS", "Slope", "Cluster", "ROS", "DeadFMC")

##LINEAR MODEL ANALYSIS FOR CLUSTERED GROUP COMPARISONS
fullmat$Cluster <- factor(fullmat$Cluster, levels = c("Mature", "L Build", "T Build", "E Build", "Build+", "Pioneer+"))

lm <- lm(ROS ~ WS*DeadFMC*as.factor(Cluster), data = fullmat)

anova(lm)

##Least square means + CLD GENERATION OF DIFFERENCES BETWEEN CLUSTERED GROUPS PREDICTED BY LINEAR MODEL
lsm <- lsmeans(lm, ~ Cluster)

cld <- cld(lsm, alpha = 0.05, Letters = letters, adjust = "tukey")
write.csv(cld, file = "cld.csv")

lsm
cld

#SET LETTERS TO ANNOTATE PLOT

letter <- c("e", "c", "d", "a", "b", "b")

##BOXPLOTS WITH ANNOTATIONS TO DISPLAY DIFFERENCES BETWEEN CLUSTERED GROUPS
par(mai = c(0.5, 1, 0.2, 0.2))

y <- expression("Rate of Spread ( m" ~ min^-1~")")

box <- boxplot(fullmat[, 27] ~ fullmat[, 26], ylim = c(0, 45), cex = 1.5, bty = 'n',  yaxt = "n", xaxt = 'n', xlab = "", ylab = "")
text(x = c(1:6), y = box$stats[nrow(box$stats), ] + 2, label = letter, col = "red", cex = 2)
axis(1, at = c(1:6), labels = c("Mature", "L Build", "T Build", "E Build", "Build+", "Pioneer+"), col.axis = "black", las = 1, cex.axis = .9, lwd = 1)
axis(2, at = c(0, 10, 20, 30, 40), labels = c(0, 10, 20, 30, 40), col.axis = "black", las = 1, cex.axis = 1.25, lwd = 1)
#title(main = "Rothermel Comparisons", cex.main = 2.5, font.main = 2.5)
mtext(y, side = 2, line = 2.6, cex = 1.25)  
#mtext(" Hierarchical Grouping", side = 1, line = 3.5, cex = 2)

######################
#DESCRIPTIVE BOXPLOTS#
######################

#Reading in data
bplotdat <- read_xlsx("2.AllData_minsavage-davis_fuelmodels.xlsx", sheet = "Bplots") 
colnames(bplotdat) <- c("FullID","Set", "ID", "MossLitter", "DWood", "AllHerb", "LWood", "Total", "FBD", "CBD", "NVC", "EUNIS", "CallStage", "Region", "Country", "TSF", "EUNIS2")

#Reorder Factors
bplotdat$CallStage <- factor(bplotdat$CallStage, levels = c("Pioneer", "Building", "Mature", "Degenerate", "Mire"))
bplotdat$NVC <- factor(bplotdat$NVC, levels = c("H8", "H12", "H12b", "M19", "M20", "M25a"))
bplotdat$EUNIS2 <- factor(bplotdat$EUNIS2, levels = c("D1.21", "D1.221", "D1.222", "F4.21", "F4.23"))
bplotdat$TSF <- factor(bplotdat$TSF, levels = c("3", "6", "12", "20", "NB"))

bplotdat$CallStage
bplotdat$NVC
bplotdat$EUNIS2
bplotdat$TSF

bp.cs.tot.y <- expression("Total ( kg " ~ m^-2~")")
bp.cs.tot <- bplotdat %>%
  ggplot(aes(x = CallStage, y = Total, fill = Region)) +
  geom_boxplot(varwidth = TRUE, width = 1) +
  scale_fill_manual(values = c("#56B4E9", "#CC79A7")) +
  scale_color_manual(values = c("#56B4E9", "#CC79A7")) +
  theme(panel.background = element_blank()) +   theme(legend.key=element_blank()) +
  theme(legend.title = element_blank(), legend.text = element_text(size = 12)) +
  theme(panel.border = element_rect(colour = "black", fill = NA, size = 0.5)) +
  theme(axis.title.y = element_text(vjust = 3)) +
  theme(axis.title.x = element_blank()) +
  labs(y = bp.cs.tot.y) +
  theme(axis.text = element_text(size = 12), axis.title = element_text(size = 12))
  #geom_point(data = bplotdat[bplotdat$Total > bplotdat$upper.limit | bplotdat$Total < bplotdat$lower.limit,], aes(x = factor(CallStage), y = Total, color = factor(Region)))
bp.cs.tot

bp.cs.lw.y <- expression("Live Woody ( kg " ~ m^-2~")")
bp.cs.lw <- bplotdat %>%
  ggplot(aes(x = CallStage, y = LWood, fill = Region)) +
  geom_boxplot(varwidth = TRUE, width = 1) +
  scale_fill_manual(values = c("#56B4E9", "#CC79A7")) +
  scale_color_manual(values = c("#56B4E9", "#CC79A7")) +
  theme(panel.background = element_blank()) +   theme(legend.key=element_blank()) +
  theme(legend.title = element_blank(), legend.text = element_text(size = 12)) +
  theme(panel.border = element_rect(colour = "black", fill = NA, size = 0.5)) +
  theme(axis.title.y = element_text(vjust = 3)) +
  theme(axis.title.x = element_blank()) +
  labs(y = bp.cs.lw.y) +
  theme(axis.text = element_text(size = 12), axis.title = element_text(size = 12))

bp.cs.dw.y <- expression("Dead Woody ( kg " ~ m^-2~")")
bp.cs.dw <- bplotdat %>%
  ggplot(aes(x = CallStage, y = DWood, fill = Region)) +
  geom_boxplot(varwidth = TRUE, width = 1) +
  scale_fill_manual(values = c("#56B4E9", "#CC79A7")) +
  scale_color_manual(values = c("#56B4E9", "#CC79A7")) +
  theme(panel.background = element_blank()) +   theme(legend.key=element_blank()) +
  theme(legend.title = element_blank(), legend.text = element_text(size = 12)) +
  theme(panel.border = element_rect(colour = "black", fill = NA, size = 0.5)) +
  theme(axis.title.y = element_text(vjust = 3)) +
  theme(axis.title.x = element_blank()) +
  labs(y = bp.cs.dw.y) +
  theme(axis.text = element_text(size = 12), axis.title = element_text(size = 12))

bp.cs.ah.y <- expression("All Herbaceous ( kg " ~ m^-2~")")
bp.cs.ah <- bplotdat %>%
  ggplot(aes(x = CallStage, y = AllHerb, fill = Region)) +
  geom_boxplot(varwidth = TRUE, width = 1) +
  scale_fill_manual(values = c("#56B4E9", "#CC79A7")) +
  scale_color_manual(values = c("#56B4E9", "#CC79A7")) +
  theme(panel.background = element_blank()) +   theme(legend.key=element_blank()) +
  theme(legend.title = element_blank(), legend.text = element_text(size = 12)) +
  theme(panel.border = element_rect(colour = "black", fill = NA, size = 0.5)) +
  theme(axis.title.y = element_text(vjust = 3)) +
  theme(axis.title.x = element_blank()) +
  labs(y = bp.cs.ah.y) +
  theme(axis.text = element_text(size = 12), axis.title = element_text(size = 12))

bp.cs.ml.y <- expression("Moss/Litter ( kg " ~ m^-2~")")
callstage.st <- expression(italic(Calluna)~" Stage")
bp.cs.ml <- bplotdat %>%
  ggplot(aes(x = CallStage, y = MossLitter, fill = Region)) +
  geom_boxplot(varwidth = TRUE, width = 1) +
  scale_fill_manual(values = c("#56B4E9", "#CC79A7")) +
  scale_color_manual(values = c("#56B4E9", "#CC79A7")) +
  theme(panel.background = element_blank()) +   theme(legend.key=element_blank()) +
  theme(axis.title.x = element_text(vjust = -1.5)) +
  theme(legend.title = element_blank(), legend.text = element_text(size = 12)) +
  labs(x = callstage.st) +
  theme(panel.border = element_rect(colour = "black", fill = NA, size = 0.5)) +
  theme(axis.title.y = element_text(vjust = 3)) +
  #theme(axis.title.x = element_blank()) +
  labs(y = bp.cs.ml.y) +
  theme(axis.text = element_text(size = 12), axis.title = element_text(size = 12))

bp.cs.fbd.y <- expression("Fuel Bed Depth ( m )")
bp.cs.fbd <- bplotdat %>%
  ggplot(aes(x = CallStage, y = FBD, fill = Region)) +
  geom_boxplot(varwidth = TRUE, width = 1) +
  scale_fill_manual(values = c("#56B4E9", "#CC79A7")) +
  scale_color_manual(values = c("#56B4E9", "#CC79A7")) +
  theme(panel.background = element_blank()) +   theme(legend.key=element_blank()) +
  theme(legend.key=element_blank()) +
  theme(axis.title.x = element_text(vjust = -1.5)) +
  theme(legend.title = element_blank(), legend.text = element_text(size = 12)) +
  labs(x = callstage.st) +
  theme(panel.border = element_rect(colour = "black", fill = NA, size = 0.5)) +
  theme(axis.title.y = element_text(vjust = 3)) +
  #theme(axis.title.x = element_blank()) +
  labs(y = bp.cs.fbd.y) +
  theme(axis.text = element_text(size = 12), axis.title = element_text(size = 12))

ggarrange(bp.cs.tot, bp.cs.lw, bp.cs.dw, bp.cs.ah, bp.cs.ml, bp.cs.fbd, ncol = 2, nrow = 3, heights = c(1, 1, 1.075), align = "v", common.legend = TRUE, legend = "bottom")

bp.eunis.tot.y <- expression("Total ( kg " ~ m^-2~")")
bp.eunis.tot <- bplotdat %>%
  ggplot(aes(x = EUNIS2, y = Total, fill = Region)) +
  geom_boxplot(varwidth = TRUE, width = 1) +
  scale_fill_manual(values = c("#56B4E9", "#CC79A7")) +
  scale_color_manual(values = c("#56B4E9", "#CC79A7")) + 
  theme(panel.background = element_blank()) +   theme(legend.key=element_blank()) +
  theme(legend.title = element_blank(), legend.text = element_text(size = 12)) +
  theme(panel.border = element_rect(colour = "black", fill = NA, size = 0.5)) +
  theme(axis.title.y = element_text(vjust = 3)) +
  theme(axis.title.x = element_blank()) +
  labs(y = bp.eunis.tot.y) +
  theme(axis.text = element_text(size = 12), axis.title = element_text(size = 12))
  #geom_point(data = bplotdat[bplotdat$Total > bplotdat$upper.limit | bplotdat$Total < bplotdat$lower.limit,], aes(x = factor(NVC), y = Total, color = factor(Region)))

bp.eunis.lw.y <- expression("Live Woody ( kg " ~ m^-2~")")
bp.eunis.lw <- bplotdat %>%
  ggplot(aes(x = EUNIS2, y = LWood, fill = Region)) +
  geom_boxplot(varwidth = TRUE, width = 1) +
  scale_fill_manual(values = c("#56B4E9", "#CC79A7")) +
  scale_color_manual(values = c("#56B4E9", "#CC79A7")) +
  theme(panel.background = element_blank()) +   theme(legend.key=element_blank()) +
  theme(legend.title = element_blank(), legend.text = element_text(size = 12)) +
  theme(panel.border = element_rect(colour = "black", fill = NA, size = 0.5)) +
  theme(axis.title.y = element_text(vjust = 3)) +
  theme(axis.title.x = element_blank()) +
  labs(y = bp.eunis.lw.y) +
  theme(axis.text = element_text(size = 12), axis.title = element_text(size = 12))

bp.eunis.dw.y <- expression("Dead Woody ( kg " ~ m^-2~")")
bp.eunis.dw <- bplotdat %>%
  ggplot(aes(x = EUNIS2, y = DWood, fill = Region)) +
  geom_boxplot(varwidth = TRUE, width = 1) +
  scale_fill_manual(values = c("#56B4E9", "#CC79A7")) +
  scale_color_manual(values = c("#56B4E9", "#CC79A7")) +
  theme(panel.background = element_blank()) +   theme(legend.key=element_blank()) +
  theme(legend.title = element_blank(), legend.text = element_text(size = 12)) +
  theme(panel.border = element_rect(colour = "black", fill = NA, size = 0.5)) +
  theme(axis.title.y = element_text(vjust = 3)) +
  theme(axis.title.x = element_blank()) +
  labs(y = bp.eunis.dw.y) +
  theme(axis.text = element_text(size = 12), axis.title = element_text(size = 12))

bp.eunis.ah.y <- expression("All Herbaceous ( kg " ~ m^-2~")")
bp.eunis.ah <- bplotdat %>%
  ggplot(aes(x = EUNIS2, y = AllHerb, fill = Region)) +
  geom_boxplot(varwidth = TRUE, width = 1) +
  scale_fill_manual(values = c("#56B4E9", "#CC79A7")) +
  scale_color_manual(values = c("#56B4E9", "#CC79A7")) +
  theme(panel.background = element_blank()) +   theme(legend.key=element_blank()) +
  theme(legend.title = element_blank(), legend.text = element_text(size = 12)) +
  theme(panel.border = element_rect(colour = "black", fill = NA, size = 0.5)) +
  theme(axis.title.y = element_text(vjust = 3)) +
  theme(axis.title.x = element_blank()) +
  labs(y = bp.eunis.ah.y) +
  theme(axis.text = element_text(size = 12), axis.title = element_text(size = 12))

bp.eunis.ml.y <- expression("Moss/Litter ( kg " ~ m^-2~")")
EUNIS2.st <- expression("EUNIS")
bp.eunis.ml <- bplotdat %>%
  ggplot(aes(x = EUNIS2, y = MossLitter, fill = Region)) +
  geom_boxplot(varwidth = TRUE, width = 1) +
  scale_fill_manual(values = c("#56B4E9", "#CC79A7")) +
  scale_color_manual(values = c("#56B4E9", "#CC79A7")) +
  theme(panel.background = element_blank()) +   theme(legend.key=element_blank()) +
  theme(axis.title.x = element_text(vjust = -1.5)) +
  theme(legend.title = element_blank(), legend.text = element_text(size = 12)) +
  labs(x = EUNIS2.st) +
  theme(panel.border = element_rect(colour = "black", fill = NA, size = 0.5)) +
  theme(axis.title.y = element_text(vjust = 3)) +
  #theme(axis.title.x = element_blank()) +
  labs(y = bp.eunis.ml.y) +
  theme(axis.text = element_text(size = 12), axis.title = element_text(size = 12))

bp.eunis.fbd.y <- expression("Fuel Bed Depth ( m )")
bp.eunis.fbd <- bplotdat %>%
  ggplot(aes(x = EUNIS2, y = FBD, fill = Region)) +
  geom_boxplot(varwidth = TRUE, width = 1) +
  scale_fill_manual(values = c("#56B4E9", "#CC79A7")) +
  scale_color_manual(values = c("#56B4E9", "#CC79A7")) +
  theme(panel.background = element_blank()) +   theme(legend.key=element_blank()) +
  theme(axis.title.x = element_text(vjust = -1.5)) +
  theme(legend.title = element_blank(), legend.text = element_text(size = 12)) +
  labs(x = EUNIS2.st) +
  theme(panel.border = element_rect(colour = "black", fill = NA, size = 0.5)) +
  theme(axis.title.y = element_text(vjust = 3)) +
  #theme(axis.title.x = element_blank()) +
  labs(y = bp.eunis.fbd.y) +
  theme(axis.text = element_text(size = 12), axis.title = element_text(size = 12))

ggarrange(bp.eunis.tot, bp.eunis.lw, bp.eunis.dw, bp.eunis.ah, bp.eunis.ml, bp.eunis.fbd, ncol = 2, nrow = 3, heights = c(1, 1, 1.075), align = "v", common.legend = TRUE, legend = "bottom")

bp.tsf.tot.y <- expression("Total ( kg " ~ m^-2~")")
bp.tsf.tot <- subset(bplotdat, !is.na(TSF)) %>%
  ggplot(aes(x = TSF, y = Total, fill = Region)) +
  geom_boxplot(varwidth = TRUE, width = 1.1) +
  scale_fill_manual(values = c("#56B4E9", "#CC79A7")) +
  scale_color_manual(values = c("#56B4E9", "#CC79A7")) +
  theme(panel.background = element_blank()) +   theme(legend.key=element_blank()) +
  theme(legend.title = element_blank(), legend.text = element_text(size = 12), legend.position = "none") +
  theme(panel.border = element_rect(colour = "black", fill = NA, size = 0.5)) +
  theme(axis.title.y = element_text(vjust = 3)) +
  theme(axis.title.x = element_blank()) +
  labs(y = bp.tsf.tot.y) +
  theme(axis.text = element_text(size = 12), axis.title = element_text(size = 12))
  #geom_point(data = bplotdat[bplotdat$Total > bplotdat$upper.limit | bplotdat$Total < bplotdat$lower.limit,], aes(x = factor(TSF), y = Total, color = factor(Region)))

bp.tsf.lw.y <- expression("Live Woody ( kg " ~ m^-2~")")
bp.tsf.lw <- subset(bplotdat, !is.na(TSF)) %>%
  ggplot(aes(x = TSF, y = LWood, fill = Region)) +
  geom_boxplot(varwidth = TRUE, width = 1.1) +
  scale_fill_manual(values = c("#56B4E9", "#CC79A7")) +
  scale_color_manual(values = c("#56B4E9", "#CC79A7")) +
  theme(panel.background = element_blank()) +   theme(legend.key=element_blank()) +
  theme(legend.title = element_blank(), legend.text = element_text(size = 12), legend.position = "none") +
  theme(panel.border = element_rect(colour = "black", fill = NA, size = 0.5)) +
  theme(axis.title.y = element_text(vjust = 3)) +
  theme(axis.title.x = element_blank()) +
  labs(y = bp.tsf.lw.y) +
  theme(axis.text = element_text(size = 12), axis.title = element_text(size = 12))

bp.tsf.dw.y <- expression("Dead Woody ( kg " ~ m^-2~")")
bp.tsf.dw <- subset(bplotdat, !is.na(TSF)) %>%
  ggplot(aes(x = TSF, y = DWood, fill = Region)) +
  geom_boxplot(varwidth = TRUE, width = 1.1) +
  scale_fill_manual(values = c("#56B4E9", "#CC79A7")) +
  scale_color_manual(values = c("#56B4E9", "#CC79A7")) +
  theme(panel.background = element_blank()) +   theme(legend.key=element_blank()) +
  theme(legend.title = element_blank(), legend.text = element_text(size = 12), legend.position = "none") +
  theme(panel.border = element_rect(colour = "black", fill = NA, size = 0.5)) +
  theme(axis.title.y = element_text(vjust = 3)) +
  theme(axis.title.x = element_blank()) +
  labs(y = bp.tsf.dw.y) +
  theme(axis.text = element_text(size = 12), axis.title = element_text(size = 12))

bp.tsf.ah.y <- expression("All Herbaceous ( kg " ~ m^-2~")")
bp.tsf.ah <- subset(bplotdat, !is.na(TSF)) %>%
  ggplot(aes(x = TSF, y = AllHerb, fill = Region)) +
  geom_boxplot(varwidth = TRUE, width = 1.1) +
  scale_fill_manual(values = c("#56B4E9", "#CC79A7")) +
  scale_color_manual(values = c("#56B4E9", "#CC79A7")) +
  theme(panel.background = element_blank()) +   theme(legend.key=element_blank()) +
  theme(legend.title = element_blank(), legend.text = element_text(size = 12), legend.position = "none") +
  theme(panel.border = element_rect(colour = "black", fill = NA, size = 0.5)) +
  theme(axis.title.y = element_text(vjust = 3)) +
  theme(axis.title.x = element_blank()) +
  labs(y = bp.tsf.ah.y) +
  theme(axis.text = element_text(size = 12), axis.title = element_text(size = 12))

bp.tsf.ml.y <- expression("Moss/Litter ( kg " ~ m^-2~")")
tsf.st <- expression("Time Since Fire (yrs)")
bp.tsf.ml <- subset(bplotdat, !is.na(TSF)) %>%
  ggplot(aes(x = TSF, y = MossLitter, fill = Region)) +
  geom_boxplot(varwidth = TRUE, width = 1.1) +
  scale_fill_manual(values = c("#56B4E9", "#CC79A7")) +
  scale_color_manual(values = c("#56B4E9", "#CC79A7")) +
  theme(panel.background = element_blank()) +   theme(legend.key=element_blank()) +
  theme(axis.title.x = element_text(vjust = -1.5)) +
  theme(legend.title = element_blank(), legend.text = element_text(size = 12), legend.position = "none") +
  labs(x = tsf.st) +
  theme(panel.border = element_rect(colour = "black", fill = NA, size = 0.5)) +
  theme(axis.title.y = element_text(vjust = 3)) +
  #theme(axis.title.x = element_blank()) +
  labs(y = bp.tsf.ml.y) +
  theme(axis.text = element_text(size = 12), axis.title = element_text(size = 12))

bp.tsf.fbd.y <- expression("Fuel Bed Depth ( m )")
bp.tsf.fbd <- subset(bplotdat, !is.na(TSF)) %>%
  ggplot(aes(x = TSF, y = FBD, fill = Region)) +
  geom_boxplot(varwidth = TRUE, width = 1.1) +
  scale_fill_manual(values = c("#56B4E9", "#CC79A7")) +
  scale_color_manual(values = c("#56B4E9", "#CC79A7")) +
  theme(panel.background = element_blank()) +   theme(legend.key=element_blank()) +
  theme(axis.title.x = element_text(vjust = -1.5)) +
  theme(legend.title = element_blank(), legend.text = element_text(size = 12), legend.position = "none") +
  labs(x = tsf.st) +
  theme(panel.border = element_rect(colour = "black", fill = NA, size = 0.5)) +
  theme(axis.title.y = element_text(vjust = 3)) +
  #theme(axis.title.x = element_blank()) +
  labs(y = bp.tsf.fbd.y) +
  theme(axis.text = element_text(size = 12), axis.title = element_text(size = 12))

ggarrange(bp.tsf.tot, bp.tsf.lw, bp.tsf.dw, bp.tsf.ah, bp.tsf.ml, bp.tsf.fbd, align = "v", ncol = 2, nrow = 3)
